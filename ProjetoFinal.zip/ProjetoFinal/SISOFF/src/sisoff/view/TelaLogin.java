package sisoff.view;

import sisoff.dao.FuncionarioDAO;
import sisoff.model.Funcionario;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;

public class TelaLogin extends JFrame {

    private JTextField txtUsuario;
    private JPasswordField txtSenha;
    private JButton btnEntrar;
    private JButton btnSair;

    public TelaLogin() {
        inicializarComponentes();
    }

    private void inicializarComponentes() {
        setTitle("Login - SISOFF");
        setSize(480, 380);
        setLocationRelativeTo(null); // centraliza
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);

        // Painel de fundo (cinza claro)
        JPanel fundo = new JPanel();
        fundo.setBackground(new Color(230, 233, 237)); // cinza suave
        fundo.setLayout(new GridBagLayout());
        setContentPane(fundo);

        // "Cartão" branco centralizado
        JPanel card = new JPanel();
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(200, 200, 200)),
                BorderFactory.createEmptyBorder(15, 20, 15, 20)
        ));
        card.setLayout(new BorderLayout(10, 10));

        // ---------- TÍTULOS (NORTE) ----------
        JPanel painelTitulos = new JPanel(new GridLayout(2, 1));
        painelTitulos.setOpaque(false);

        JLabel lblTitulo = new JLabel("SISOFF", SwingConstants.CENTER);
        lblTitulo.setFont(new Font("SansSerif", Font.BOLD, 20));

        JLabel lblSubtitulo = new JLabel("Sistema de Gestão Offshore", SwingConstants.CENTER);
        lblSubtitulo.setFont(new Font("SansSerif", Font.PLAIN, 13));
        lblSubtitulo.setForeground(new Color(80, 80, 80));

        painelTitulos.add(lblTitulo);
        painelTitulos.add(lblSubtitulo);

        card.add(painelTitulos, BorderLayout.NORTH);

        // ---------- IMAGEM (CENTRO) ----------
        JLabel lblImagem = new JLabel();
        lblImagem.setHorizontalAlignment(SwingConstants.CENTER);

        try {
            // A imagem deve estar em: src/sisoff/imagens/offshore.jpg
            ImageIcon icon = new ImageIcon(
                    getClass().getResource("/sisoff/imagens/Imagem Offshore.jpg")
            );

            Image img = icon.getImage();
            // Ajusta o tamanho para caber bem dentro do card
            Image imgRedimensionada = img.getScaledInstance(420, 130, Image.SCALE_SMOOTH);
            icon = new ImageIcon(imgRedimensionada);

            lblImagem.setIcon(icon);
        } catch (Exception e) {
            // Se não encontrar a imagem, mostra um texto no lugar
            lblImagem.setText("Imagem offshore não encontrada");
            lblImagem.setFont(new Font("SansSerif", Font.ITALIC, 12));
        }

        card.add(lblImagem, BorderLayout.CENTER);

        // ---------- CAMPOS + BOTÕES (SUL) ----------
        JPanel painelCampos = new JPanel(new GridBagLayout());
        painelCampos.setOpaque(false);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(6, 6, 6, 6);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel lblUsuario = new JLabel("Usuário:");
        JLabel lblSenha = new JLabel("Senha:");

        txtUsuario = new JTextField(20);
        txtSenha = new JPasswordField(20);

        // Linha 1 - Usuário
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.weightx = 0;
        painelCampos.add(lblUsuario, gbc);

        gbc.gridx = 1;
        gbc.weightx = 1;
        painelCampos.add(txtUsuario, gbc);

        // Linha 2 - Senha
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.weightx = 0;
        painelCampos.add(lblSenha, gbc);

        gbc.gridx = 1;
        gbc.weightx = 1;
        painelCampos.add(txtSenha, gbc);

        // Painel de botões
        JPanel painelBotoes = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        painelBotoes.setOpaque(false);

        btnEntrar = new JButton("Entrar");
        btnSair = new JButton("Sair");

        btnEntrar.setPreferredSize(new Dimension(90, 28));
        btnSair.setPreferredSize(new Dimension(80, 28));

        painelBotoes.add(btnEntrar);
        painelBotoes.add(btnSair);

        // Junta campos + botões num painel inferior
        JPanel painelInferior = new JPanel(new BorderLayout());
        painelInferior.setOpaque(false);
        painelInferior.add(painelCampos, BorderLayout.CENTER);
        painelInferior.add(painelBotoes, BorderLayout.SOUTH);

        card.add(painelInferior, BorderLayout.SOUTH);

        // Adiciona o "card" no fundo
        GridBagConstraints gbcFundo = new GridBagConstraints();
        gbcFundo.gridx = 0;
        gbcFundo.gridy = 0;
        fundo.add(card, gbcFundo);

        // ---------- AÇÕES ----------
        btnEntrar.addActionListener((ActionEvent e) -> realizarLogin());
        btnSair.addActionListener((ActionEvent e) -> System.exit(0));

        // ENTER no campo senha também faz login
        txtSenha.addActionListener((ActionEvent e) -> realizarLogin());

        // Atalho: ESC para sair
        fundo.getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW)
                .put(KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0), "sair");
        fundo.getActionMap().put("sair", new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });
    }

    private void realizarLogin() {
        String usuario = txtUsuario.getText().trim();
        String senha = new String(txtSenha.getPassword()).trim();

        if (usuario.isEmpty() || senha.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "Informe usuário e senha.",
                    "Campos obrigatórios",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        try {
            FuncionarioDAO dao = new FuncionarioDAO();
            Funcionario f = dao.buscarPorUsuarioESenha(usuario, senha);

            if (f != null) {
                JOptionPane.showMessageDialog(this,
                        "Login realizado com sucesso! Bem-vindo, " + f.getNome() + ".",
                        "Sucesso",
                        JOptionPane.INFORMATION_MESSAGE);

                // Abre a tela principal
                TelaPrincipal telaPrincipal = new TelaPrincipal();
                telaPrincipal.setVisible(true);

                // Fecha a tela de login
                this.dispose();
            } else {
                JOptionPane.showMessageDialog(this,
                        "Usuário ou senha inválidos, ou usuário inativo.",
                        "Falha no login",
                        JOptionPane.ERROR_MESSAGE);
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this,
                    "Erro ao realizar login: " + ex.getMessage(),
                    "Erro",
                    JOptionPane.ERROR_MESSAGE);
            ex.printStackTrace();
        }
    }

    public static void main(String[] args) {
        // Look & Feel nativo do sistema operacional
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ignored) {
        }

        SwingUtilities.invokeLater(() -> {
            new TelaLogin().setVisible(true);
        });
    }
}


