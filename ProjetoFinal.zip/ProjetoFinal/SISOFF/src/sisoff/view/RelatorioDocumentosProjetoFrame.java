package sisoff.view;

import sisoff.dao.DocumentoProjetoDAO;
import sisoff.dao.ProjetoOffshoreDAO;
import sisoff.dao.EtapaProjetoDAO;

import sisoff.model.DocumentoProjeto;
import sisoff.model.ProjetoOffshore;
import sisoff.model.EtapaProjeto;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class RelatorioDocumentosProjetoFrame extends JInternalFrame {

    private JComboBox<String> cbProjeto;
    private JButton btnFiltrar;
    private JButton btnLimpar;
    private JTable tabela;
    private DefaultTableModel modelo;

    private DocumentoProjetoDAO documentoDAO;
    private ProjetoOffshoreDAO projetoDAO;
    private EtapaProjetoDAO etapaDAO;

    private List<ProjetoOffshore> listaProjetos = new ArrayList<>();
    private List<EtapaProjeto> listaEtapas = new ArrayList<>();
    private List<DocumentoProjeto> listaDocumentos = new ArrayList<>();

    public RelatorioDocumentosProjetoFrame() {
        super("Relatório - Documentos por Projeto", true, true, true, true);

        documentoDAO = new DocumentoProjetoDAO();
        projetoDAO = new ProjetoOffshoreDAO();
        etapaDAO = new EtapaProjetoDAO();

        inicializarComponentes();
        carregarProjetos();
        carregarEtapas();
        carregarDocumentos(); // carrega todos inicialmente
    }

    private void inicializarComponentes() {
        setSize(950, 550);
        setLayout(new BorderLayout(10, 10));

        // Painel de filtro
        JPanel painelFiltro = new JPanel(new FlowLayout(FlowLayout.LEFT));
        painelFiltro.setBorder(BorderFactory.createTitledBorder("Filtro"));

        JLabel lblProjeto = new JLabel("Projeto:");

        cbProjeto = new JComboBox<>();
        cbProjeto.addItem("Todos os projetos");

        btnFiltrar = new JButton("Filtrar");
        btnLimpar = new JButton("Limpar");

        painelFiltro.add(lblProjeto);
        painelFiltro.add(cbProjeto);
        painelFiltro.add(btnFiltrar);
        painelFiltro.add(btnLimpar);

        // Tabela
        modelo = new DefaultTableModel(
                new Object[]{
                        "ID Doc",
                        "Projeto",
                        "Etapa",
                        "Tipo",
                        "Título",
                        "Data Emissão",
                        "Responsável"
                }, 0
        ) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        tabela = new JTable(modelo);
        JScrollPane scrollTabela = new JScrollPane(tabela);
        scrollTabela.setBorder(BorderFactory.createTitledBorder("Documentos"));

        add(painelFiltro, BorderLayout.NORTH);
        add(scrollTabela, BorderLayout.CENTER);

        // Eventos
        btnFiltrar.addActionListener(e -> aplicarFiltro());
        btnLimpar.addActionListener(e -> limparFiltro());
    }

    private void carregarProjetos() {
        cbProjeto.removeAllItems();
        cbProjeto.addItem("Todos os projetos");
        try {
            listaProjetos = projetoDAO.listarTodos();
            for (ProjetoOffshore p : listaProjetos) {
                cbProjeto.addItem(p.getIdProjeto() + " - " + p.getNomeProjeto());
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                    "Erro ao carregar projetos: " + e.getMessage(),
                    "Erro",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    private void carregarEtapas() {
        try {
            listaEtapas = etapaDAO.listarTodas();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                    "Erro ao carregar etapas: " + e.getMessage(),
                    "Erro",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    private void carregarDocumentos() {
        modelo.setRowCount(0);
        listaDocumentos.clear();

        try {
            listaDocumentos = documentoDAO.listarTodos();

            for (DocumentoProjeto d : listaDocumentos) {
                String nomeProjeto = buscarNomeProjeto(d.getIdProjeto());
                String nomeEtapa = buscarNomeEtapa(d.getIdEtapa());

                modelo.addRow(new Object[]{
                        d.getIdDocumento(),
                        nomeProjeto,
                        nomeEtapa,
                        d.getTipoDocumento(),
                        d.getTitulo(),
                        d.getDataEmissao() != null ? d.getDataEmissao().toString() : "",
                        d.getResponsavelElaboracao()
                });
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                    "Erro ao carregar documentos: " + e.getMessage(),
                    "Erro",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    private void aplicarFiltro() {
        int idxProj = cbProjeto.getSelectedIndex();

        modelo.setRowCount(0);

        for (DocumentoProjeto d : listaDocumentos) {

            // Se escolheu um projeto específico
            if (idxProj > 0) {
                ProjetoOffshore p = listaProjetos.get(idxProj - 1);
                if (d.getIdProjeto() != p.getIdProjeto()) {
                    continue;
                }
            }

            String nomeProjeto = buscarNomeProjeto(d.getIdProjeto());
            String nomeEtapa = buscarNomeEtapa(d.getIdEtapa());

            modelo.addRow(new Object[]{
                    d.getIdDocumento(),
                    nomeProjeto,
                    nomeEtapa,
                    d.getTipoDocumento(),
                    d.getTitulo(),
                    d.getDataEmissao() != null ? d.getDataEmissao().toString() : "",
                    d.getResponsavelElaboracao()
            });
        }
    }

    private void limparFiltro() {
        cbProjeto.setSelectedIndex(0);
        carregarDocumentos();
    }

    private String buscarNomeProjeto(int idProjeto) {
        for (ProjetoOffshore p : listaProjetos) {
            if (p.getIdProjeto() == idProjeto) {
                return p.getNomeProjeto();
            }
        }
        return "-";
    }

    private String buscarNomeEtapa(Integer idEtapa) {
        if (idEtapa == null) return "-";
        for (EtapaProjeto e : listaEtapas) {
            if (e.getIdEtapa() == idEtapa) {
                return e.getNomeEtapa();
            }
        }
        return "-";
    }
}
