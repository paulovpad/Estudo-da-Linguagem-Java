package sisoff.view;

import sisoff.dao.DocumentoProjetoDAO;
import sisoff.dao.EtapaProjetoDAO;
import sisoff.dao.FuncionarioDAO;
import sisoff.dao.ProjetoOffshoreDAO;

import sisoff.model.DocumentoProjeto;
import sisoff.model.EtapaProjeto;
import sisoff.model.Funcionario;
import sisoff.model.ProjetoOffshore;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

public class CadastroDocumentoProjetoFrame extends JInternalFrame {

    private JTextField txtId;
    private JComboBox<String> cbProjeto;
    private JComboBox<String> cbEtapa;
    private JTextField txtTitulo;
    private JComboBox<String> cbTipoDocumento;
    private JTextField txtDataEmissao;
    private JComboBox<String> cbResponsavel;
    private JTextArea txtObservacao;

    private JButton btnNovo;
    private JButton btnEditar;
    private JButton btnSalvar;
    private JButton btnExcluir;
    private JButton btnCancelar;
    private JButton btnAtualizar;

    private JTable tabela;
    private DefaultTableModel modelo;

    private DocumentoProjetoDAO documentoDAO;
    private ProjetoOffshoreDAO projetoDAO;
    private EtapaProjetoDAO etapaDAO;
    private FuncionarioDAO funcionarioDAO;

    private List<ProjetoOffshore> listaProjetos = new ArrayList<>();
    private List<EtapaProjeto> listaEtapas = new ArrayList<>();
    private List<Funcionario> listaFuncionarios = new ArrayList<>();
    private List<DocumentoProjeto> listaDocumentos = new ArrayList<>();

    private boolean modoEdicao = false;

    public CadastroDocumentoProjetoFrame() {
        super("Documentos de Projeto", true, true, true, true);

        documentoDAO = new DocumentoProjetoDAO();
        projetoDAO = new ProjetoOffshoreDAO();
        etapaDAO = new EtapaProjetoDAO();
        funcionarioDAO = new FuncionarioDAO();

        inicializarComponentes();
        configurarEventos();
        carregarProjetosCombo();
        carregarFuncionariosCombo();
        carregarDocumentos();
        habilitarCampos(false);
    }

    private void inicializarComponentes() {
        setSize(950, 580);
        setLayout(new BorderLayout(10, 10));

        JPanel painelForm = new JPanel(new GridBagLayout());
        painelForm.setBorder(BorderFactory.createTitledBorder("Dados do Documento"));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(4,4,4,4);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel lblId = new JLabel("ID:");
        JLabel lblProjeto = new JLabel("Projeto:");
        JLabel lblEtapa = new JLabel("Etapa (opcional):");
        JLabel lblTitulo = new JLabel("Título do Documento:");
        JLabel lblTipo = new JLabel("Tipo:");
        JLabel lblDataEmissao = new JLabel("Data de Emissão (AAAA-MM-DD):");
        JLabel lblResponsavel = new JLabel("Responsável:");
        JLabel lblObs = new JLabel("Observação:");

        txtId = new JTextField(5);
        txtId.setEditable(false);

        cbProjeto = new JComboBox<>();
        cbEtapa = new JComboBox<>();
        cbEtapa.addItem("Nenhuma etapa vinculada");

        txtTitulo = new JTextField(25);

        cbTipoDocumento = new JComboBox<>(new String[]{
                "Selecione...",
                "Plano de Trabalho",
                "Cronograma",
                "Relatório Técnico",
                "ATA de Reunião",
                "Check-list",
                "Certificação",
                "Relatório de Inspeção",
                "Documentação Fotográfica",
                "Outros"
        });

        txtDataEmissao = new JTextField(10);

        cbResponsavel = new JComboBox<>();
        cbResponsavel.addItem("Selecione...");

        txtObservacao = new JTextArea(4, 30);
        txtObservacao.setLineWrap(true);
        txtObservacao.setWrapStyleWord(true);

        JScrollPane scrollObs = new JScrollPane(txtObservacao);
        JPanel painelObs = new JPanel(new BorderLayout());
        painelObs.setBorder(BorderFactory.createTitledBorder("Observações"));
        painelObs.add(scrollObs, BorderLayout.CENTER);

        int y = 0;

        // ID
        gbc.gridx = 0; gbc.gridy = y; painelForm.add(lblId, gbc);
        gbc.gridx = 1; gbc.gridy = y; painelForm.add(txtId, gbc);

        // Projeto
        y++;
        gbc.gridx = 0; gbc.gridy = y; painelForm.add(lblProjeto, gbc);
        gbc.gridx = 1; painelForm.add(cbProjeto, gbc);

        // Etapa
        y++;
        gbc.gridx = 0; gbc.gridy = y; painelForm.add(lblEtapa, gbc);
        gbc.gridx = 1; painelForm.add(cbEtapa, gbc);

        // Título
        y++;
        gbc.gridx = 0; gbc.gridy = y; painelForm.add(lblTitulo, gbc);
        gbc.gridx = 1; painelForm.add(txtTitulo, gbc);

        // Tipo
        y++;
        gbc.gridx = 0; gbc.gridy = y; painelForm.add(lblTipo, gbc);
        gbc.gridx = 1; painelForm.add(cbTipoDocumento, gbc);

        // Data Emissão
        y++;
        gbc.gridx = 0; gbc.gridy = y; painelForm.add(lblDataEmissao, gbc);
        gbc.gridx = 1; painelForm.add(txtDataEmissao, gbc);

        // Responsável
        y++;
        gbc.gridx = 0; gbc.gridy = y; painelForm.add(lblResponsavel, gbc);
        gbc.gridx = 1; painelForm.add(cbResponsavel, gbc);

        // Observação
        y++;
        gbc.gridx = 0; gbc.gridy = y; painelForm.add(lblObs, gbc);
        gbc.gridx = 1; painelForm.add(painelObs, gbc);

        JPanel painelBotoes = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        btnNovo = new JButton("Novo");
        btnEditar = new JButton("Editar");
        btnSalvar = new JButton("Salvar");
        btnExcluir = new JButton("Excluir");
        btnCancelar = new JButton("Cancelar");
        btnAtualizar = new JButton("Atualizar Lista");

        btnSalvar.setEnabled(false);
        btnCancelar.setEnabled(false);

        painelBotoes.add(btnNovo);
        painelBotoes.add(btnEditar);
        painelBotoes.add(btnSalvar);
        painelBotoes.add(btnExcluir);
        painelBotoes.add(btnCancelar);
        painelBotoes.add(btnAtualizar);

        modelo = new DefaultTableModel(
                new Object[]{
                        "ID", "Projeto", "Etapa", "Tipo",
                        "Título", "Data Emissão", "Responsável"
                }, 0
        ) {
            @Override
            public boolean isCellEditable(int r, int c) { return false; }
        };

        tabela = new JTable(modelo);
        JScrollPane scrollTabela = new JScrollPane(tabela);
        scrollTabela.setBorder(BorderFactory.createTitledBorder("Documentos cadastrados"));

        JPanel topo = new JPanel(new BorderLayout());
        topo.add(painelForm, BorderLayout.CENTER);
        topo.add(painelBotoes, BorderLayout.SOUTH);

        add(topo, BorderLayout.NORTH);
        add(scrollTabela, BorderLayout.CENTER);
    }

    private void habilitarCampos(boolean ativo) {
        cbProjeto.setEnabled(ativo);
        cbEtapa.setEnabled(ativo);
        txtTitulo.setEnabled(ativo);
        cbTipoDocumento.setEnabled(ativo);
        txtDataEmissao.setEnabled(ativo);
        cbResponsavel.setEnabled(ativo);
        txtObservacao.setEnabled(ativo);
    }

    private void limparCampos() {
        txtId.setText("");
        cbProjeto.setSelectedIndex(0);
        cbEtapa.setSelectedIndex(0);
        txtTitulo.setText("");
        cbTipoDocumento.setSelectedIndex(0);
        txtDataEmissao.setText("");
        cbResponsavel.setSelectedIndex(0);
        txtObservacao.setText("");
        tabela.clearSelection();
    }

    private void novo() {
        modoEdicao = false;
        limparCampos();
        habilitarCampos(true);
        btnSalvar.setEnabled(true);
        btnCancelar.setEnabled(true);
    }

    private void editar() {
        if (txtId.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Selecione um documento para editar.");
            return;
        }
        modoEdicao = true;
        habilitarCampos(true);
        btnSalvar.setEnabled(true);
        btnCancelar.setEnabled(true);
    }

    private void cancelar() {
        limparCampos();
        habilitarCampos(false);
        btnSalvar.setEnabled(false);
        btnCancelar.setEnabled(false);
        modoEdicao = false;
    }

    private void excluir() {
        if (txtId.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Selecione um documento para excluir.");
            return;
        }
        int op = JOptionPane.showConfirmDialog(this,
                "Deseja realmente excluir este documento?",
                "Excluir",
                JOptionPane.YES_NO_OPTION);
        if (op == JOptionPane.YES_OPTION) {
            try {
                int id = Integer.parseInt(txtId.getText());
                documentoDAO.deletar(id);
                JOptionPane.showMessageDialog(this, "Documento excluído com sucesso.");
                carregarDocumentos();
                limparCampos();
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this,
                        "Erro ao excluir documento: " + e.getMessage(),
                        "Erro",
                        JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void carregarProjetosCombo() {
        cbProjeto.removeAllItems();
        listaProjetos.clear();
        cbProjeto.addItem("Selecione...");
        try {
            listaProjetos = projetoDAO.listarTodos();
            for (ProjetoOffshore p : listaProjetos) {
                cbProjeto.addItem(p.getIdProjeto() + " - " + p.getNomeProjeto());
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                    "Erro ao carregar projetos: " + e.getMessage(),
                    "Erro",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    private void carregarFuncionariosCombo() {
        cbResponsavel.removeAllItems();
        listaFuncionarios.clear();
        cbResponsavel.addItem("Selecione...");
        try {
            List<Funcionario> lista = funcionarioDAO.listarTodos();
            for (Funcionario f : lista) {
                if (f.isAtivo()) {
                    listaFuncionarios.add(f);
                    cbResponsavel.addItem(f.getIdFuncionario() + " - " + f.getNome());
                }
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                    "Erro ao carregar responsáveis: " + e.getMessage(),
                    "Erro",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    private void carregarEtapasDoProjeto(int idProjeto) {
        cbEtapa.removeAllItems();
        cbEtapa.addItem("Nenhuma etapa vinculada");
        listaEtapas.clear();
        try {
            List<EtapaProjeto> todas = etapaDAO.listarTodas();
            for (EtapaProjeto et : todas) {
                if (et.getIdProjeto() == idProjeto) {
                    listaEtapas.add(et);
                    cbEtapa.addItem(et.getIdEtapa() + " - " + et.getNomeEtapa());
                }
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                    "Erro ao carregar etapas: " + e.getMessage(),
                    "Erro",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    private void carregarDocumentos() {
        modelo.setRowCount(0);
        listaDocumentos.clear();
        try {
            listaDocumentos = documentoDAO.listarTodos();
            for (DocumentoProjeto d : listaDocumentos) {
                String nomeProjeto = buscarNomeProjeto(d.getIdProjeto());
                String nomeEtapa = buscarNomeEtapa(d.getIdEtapa());
                modelo.addRow(new Object[]{
                        d.getIdDocumento(),
                        nomeProjeto,
                        nomeEtapa,
                        d.getTipoDocumento(),
                        d.getTitulo(),
                        d.getDataEmissao() != null ? d.getDataEmissao().toString() : "",
                        d.getResponsavelElaboracao()
                });
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                    "Erro ao carregar documentos: " + e.getMessage(),
                    "Erro",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    private String buscarNomeProjeto(int idProjeto) {
        for (ProjetoOffshore p : listaProjetos) {
            if (p.getIdProjeto() == idProjeto) {
                return p.getNomeProjeto();
            }
        }
        return "-";
    }

    private String buscarNomeEtapa(Integer idEtapa) {
        if (idEtapa == null) return "-";
        for (EtapaProjeto e : listaEtapas) {
            if (e.getIdEtapa() == idEtapa) {
                return e.getNomeEtapa();
            }
        }
        return "-";
    }

    private void carregarDaTabela(int linha) {
        if (linha < 0 || linha >= listaDocumentos.size()) return;
        DocumentoProjeto d = listaDocumentos.get(linha);

        txtId.setText(String.valueOf(d.getIdDocumento()));
        txtTitulo.setText(d.getTitulo());
        txtDataEmissao.setText(d.getDataEmissao() != null ? d.getDataEmissao().toString() : "");
        txtObservacao.setText(d.getObservacao() != null ? d.getObservacao() : "");

        int idxProj = 0;
        for (int i = 0; i < listaProjetos.size(); i++) {
            if (listaProjetos.get(i).getIdProjeto() == d.getIdProjeto()) {
                idxProj = i + 1;
                break;
            }
        }
        cbProjeto.setSelectedIndex(idxProj);

        carregarEtapasDoProjeto(d.getIdProjeto());
        if (d.getIdEtapa() != null) {
            int idxEtapa = 0;
            for (int i = 0; i < listaEtapas.size(); i++) {
                if (listaEtapas.get(i).getIdEtapa() == d.getIdEtapa()) {
                    idxEtapa = i + 1;
                    break;
                }
            }
            cbEtapa.setSelectedIndex(idxEtapa);
        } else {
            cbEtapa.setSelectedIndex(0);
        }

        cbTipoDocumento.setSelectedItem(d.getTipoDocumento());

        int idxResp = 0;
        for (int i = 0; i < listaFuncionarios.size(); i++) {
            if (listaFuncionarios.get(i).getNome().equals(d.getResponsavelElaboracao())) {
                idxResp = i + 1;
                break;
            }
        }
        cbResponsavel.setSelectedIndex(idxResp);

        habilitarCampos(false);
        btnSalvar.setEnabled(false);
        btnCancelar.setEnabled(false);
        modoEdicao = false;
    }

    private void salvar() {
        int idxProj = cbProjeto.getSelectedIndex();
        int idxResp = cbResponsavel.getSelectedIndex();

        if (idxProj <= 0) {
            JOptionPane.showMessageDialog(this, "Selecione um Projeto.");
            return;
        }
        if (idxResp <= 0) {
            JOptionPane.showMessageDialog(this, "Selecione o Responsável.");
            return;
        }
        if (txtTitulo.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Informe o Título do Documento.");
            return;
        }
        if (cbTipoDocumento.getSelectedIndex() == 0) {
            JOptionPane.showMessageDialog(this, "Selecione um Tipo de Documento.");
            return;
        }

        DocumentoProjeto d = new DocumentoProjeto();
        if (modoEdicao) {
            d.setIdDocumento(Integer.parseInt(txtId.getText()));
        }

        ProjetoOffshore proj = listaProjetos.get(idxProj - 1);
        d.setIdProjeto(proj.getIdProjeto());

        int idxEtapa = cbEtapa.getSelectedIndex();
        if (idxEtapa > 0 && idxEtapa - 1 < listaEtapas.size()) {
            EtapaProjeto et = listaEtapas.get(idxEtapa - 1);
            d.setIdEtapa(et.getIdEtapa());
        } else {
            d.setIdEtapa(null);
        }

        d.setTitulo(txtTitulo.getText().trim());
        d.setTipoDocumento(cbTipoDocumento.getSelectedItem().toString());

        String dataTxt = txtDataEmissao.getText().trim();
        try {
            d.setDataEmissao(dataTxt.isEmpty() ? null : Date.valueOf(dataTxt));
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                    "Data inválida. Use o formato AAAA-MM-DD.",
                    "Erro",
                    JOptionPane.ERROR_MESSAGE);
            return;
        }

        Funcionario f = listaFuncionarios.get(idxResp - 1);
        d.setResponsavelElaboracao(f.getNome());
        d.setObservacao(txtObservacao.getText().trim());

        try {
            if (modoEdicao) {
                documentoDAO.atualizar(d);
                JOptionPane.showMessageDialog(this, "Documento atualizado com sucesso.");
            } else {
                documentoDAO.inserir(d);
                JOptionPane.showMessageDialog(this, "Documento inserido com sucesso.");
            }
            carregarDocumentos();
            cancelar();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this,
                    "Erro ao salvar documento: " + ex.getMessage(),
                    "Erro",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    private void configurarEventos() {
        btnNovo.addActionListener(e -> novo());
        btnEditar.addActionListener(e -> editar());
        btnSalvar.addActionListener(e -> salvar());
        btnExcluir.addActionListener(e -> excluir());
        btnCancelar.addActionListener(e -> cancelar());
        btnAtualizar.addActionListener(e -> carregarDocumentos());

        tabela.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int linha = tabela.getSelectedRow();
                carregarDaTabela(linha);
            }
        });

        cbProjeto.addActionListener(e -> {
            int idx = cbProjeto.getSelectedIndex();
            if (idx > 0 && idx - 1 < listaProjetos.size()) {
                ProjetoOffshore p = listaProjetos.get(idx - 1);
                carregarEtapasDoProjeto(p.getIdProjeto());
            }
        });
    }
}



