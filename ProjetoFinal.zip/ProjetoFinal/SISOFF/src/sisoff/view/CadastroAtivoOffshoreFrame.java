package sisoff.view;

import sisoff.dao.AtivoOffshoreDAO;
import sisoff.model.AtivoOffshore;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.List;

public class CadastroAtivoOffshoreFrame extends JInternalFrame {

    private JTextField txtId;
    private JTextField txtNome;
    private JTextField txtTipo;
    private JTextField txtLocalizacao;
    private JTextField txtOperador;

    private JButton btnNovo;
    private JButton btnEditar;
    private JButton btnSalvar;
    private JButton btnExcluir;
    private JButton btnCancelar;
    private JButton btnAtualizar;

    private JTable tabela;
    private DefaultTableModel modelo;

    private AtivoOffshoreDAO ativoDAO;

    private boolean modoEdicao = false;

    public CadastroAtivoOffshoreFrame() {
        super("Cadastro de Ativos Offshore", true, true, true, true);
        ativoDAO = new AtivoOffshoreDAO();
        inicializarComponentes();
        carregarAtivos();
        habilitarCampos(false);
    }

    private void inicializarComponentes() {
        setSize(750, 430);
        setLayout(new BorderLayout(10, 10));

        JPanel painel = new JPanel(new GridBagLayout());
        painel.setBorder(BorderFactory.createTitledBorder("Dados do Ativo"));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(4, 4, 4, 4);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel lblId = new JLabel("ID:");
        JLabel lblNome = new JLabel("Nome:");
        JLabel lblTipo = new JLabel("Tipo:");
        JLabel lblLocal = new JLabel("Localização:");
        JLabel lblOperador = new JLabel("Operador:");

        txtId = new JTextField(5); txtId.setEditable(false);
        txtNome = new JTextField(25);
        txtTipo = new JTextField(20);
        txtLocalizacao = new JTextField(20);
        txtOperador = new JTextField(20);

        int y = 0;

        gbc.gridx=0; gbc.gridy=y; painel.add(lblId, gbc);
        gbc.gridx=1; painel.add(txtId, gbc);

        y++; gbc.gridx=0; gbc.gridy=y; painel.add(lblNome, gbc);
        gbc.gridx=1; painel.add(txtNome, gbc);

        y++; gbc.gridx=0; gbc.gridy=y; painel.add(lblTipo, gbc);
        gbc.gridx=1; painel.add(txtTipo, gbc);

        y++; gbc.gridx=0; gbc.gridy=y; painel.add(lblLocal, gbc);
        gbc.gridx=1; painel.add(txtLocalizacao, gbc);

        y++; gbc.gridx=0; gbc.gridy=y; painel.add(lblOperador, gbc);
        gbc.gridx=1; painel.add(txtOperador, gbc);

        JPanel botoes = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        btnNovo = new JButton("Novo");
        btnEditar = new JButton("Editar");
        btnSalvar = new JButton("Salvar");
        btnExcluir = new JButton("Excluir");
        btnCancelar = new JButton("Cancelar");
        btnAtualizar = new JButton("Atualizar");

        btnSalvar.setEnabled(false);
        btnCancelar.setEnabled(false);

        botoes.add(btnNovo);
        botoes.add(btnEditar);
        botoes.add(btnSalvar);
        botoes.add(btnExcluir);
        botoes.add(btnCancelar);
        botoes.add(btnAtualizar);

        modelo = new DefaultTableModel(
                new Object[]{"ID", "Nome", "Tipo", "Localização", "Operador"}, 0
        ) {
            @Override public boolean isCellEditable(int r, int c){ return false; }
        };
        tabela = new JTable(modelo);
        JScrollPane sc = new JScrollPane(tabela);

        JPanel topo = new JPanel(new BorderLayout());
        topo.add(painel, BorderLayout.CENTER);
        topo.add(botoes, BorderLayout.SOUTH);

        add(topo, BorderLayout.NORTH);
        add(sc, BorderLayout.CENTER);

        // Ações
        btnNovo.addActionListener(e -> novo());
        btnEditar.addActionListener(e -> editar());
        btnSalvar.addActionListener(e -> salvar());
        btnExcluir.addActionListener(e -> excluir());
        btnCancelar.addActionListener(e -> cancelar());
        btnAtualizar.addActionListener(e -> carregarAtivos());

        tabela.addMouseListener(new MouseAdapter() {
            @Override public void mouseClicked(MouseEvent e) {
                carregarDaTabela(tabela.getSelectedRow());
            }
        });
    }

    private void habilitarCampos(boolean ativo) {
        txtNome.setEnabled(ativo);
        txtTipo.setEnabled(ativo);
        txtLocalizacao.setEnabled(ativo);
        txtOperador.setEnabled(ativo);
    }

    private void novo() {
        modoEdicao = false;
        limparCampos();
        habilitaParaEdicao();
    }

    private void editar() {
        if (txtId.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this,"Selecione um ativo.");
            return;
        }
        modoEdicao = true;
        habilitaParaEdicao();
    }

    private void habilitaParaEdicao() {
        habilitarCampos(true);
        btnSalvar.setEnabled(true);
        btnCancelar.setEnabled(true);
    }

    private void salvar() {
        if (txtNome.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this,"Nome obrigatório.");
            return;
        }

        AtivoOffshore a = new AtivoOffshore();
        if (modoEdicao) a.setIdAtivo(Integer.parseInt(txtId.getText()));

        a.setNomeAtivo(txtNome.getText());
        a.setTipoAtivo(txtTipo.getText());
        a.setLocalizacao(txtLocalizacao.getText());
        a.setOperador(txtOperador.getText());

        try {
            if (modoEdicao) ativoDAO.atualizar(a);
            else ativoDAO.inserir(a);

            JOptionPane.showMessageDialog(this,"Salvo com sucesso!");
            carregarAtivos();
            cancelar();

        } catch (Exception ex){
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this,"ERRO: "+ex.getMessage());
        }
    }

    private void excluir() {
        if (txtId.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this,"Selecione um ativo.");
            return;
        }

        int op = JOptionPane.showConfirmDialog(this,"Excluir ativo?");
        if (op == JOptionPane.YES_OPTION) {
            ativoDAO.deletar(Integer.parseInt(txtId.getText()));
            carregarAtivos();
            limparCampos();
        }
    }

    private void cancelar() {
        limparCampos();
        habilitarCampos(false);
        btnSalvar.setEnabled(false);
        btnCancelar.setEnabled(false);
    }

    private void carregarAtivos() {
        modelo.setRowCount(0);
        for (AtivoOffshore a : ativoDAO.listarTodos()) {
            modelo.addRow(new Object[]{
                    a.getIdAtivo(),
                    a.getNomeAtivo(),
                    a.getTipoAtivo(),
                    a.getLocalizacao(),
                    a.getOperador()
            });
        }
    }

    private void carregarDaTabela(int linha) {
        if (linha < 0) return;

        txtId.setText(modelo.getValueAt(linha,0).toString());
        txtNome.setText(modelo.getValueAt(linha,1).toString());
        txtTipo.setText(modelo.getValueAt(linha,2).toString());
        txtLocalizacao.setText(modelo.getValueAt(linha,3).toString());
        txtOperador.setText(modelo.getValueAt(linha,4).toString());

        habilitarCampos(false);
    }

    private void limparCampos() {
        txtId.setText("");
        txtNome.setText("");
        txtTipo.setText("");
        txtLocalizacao.setText("");
        txtOperador.setText("");
        tabela.clearSelection();
    }
}
