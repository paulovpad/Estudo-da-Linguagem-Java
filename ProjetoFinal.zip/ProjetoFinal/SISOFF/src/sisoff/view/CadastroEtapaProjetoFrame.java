package sisoff.view;

import sisoff.dao.EtapaProjetoDAO;
import sisoff.dao.FuncionarioDAO;
import sisoff.dao.ProjetoOffshoreDAO;
import sisoff.model.EtapaProjeto;
import sisoff.model.Funcionario;
import sisoff.model.ProjetoOffshore;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

public class CadastroEtapaProjetoFrame extends JInternalFrame {

    private JTextField txtId;
    private JComboBox<String> cbProjeto;
    private JComboBox<String> cbResponsavel;
    private JTextField txtNomeEtapa;
    private JTextField txtDataPrevistaInicio;
    private JTextField txtDataPrevistaFim;
    private JTextField txtDataConclusao;
    private JComboBox<String> cbStatus;
    private JTextArea txtObservacao;

    private JButton btnNovo;
    private JButton btnEditar;
    private JButton btnSalvar;
    private JButton btnExcluir;
    private JButton btnCancelar;
    private JButton btnAtualizar;

    private JTable tabela;
    private DefaultTableModel modelo;

    private EtapaProjetoDAO etapaDAO;
    private ProjetoOffshoreDAO projetoDAO;
    private FuncionarioDAO funcionarioDAO;

    private List<ProjetoOffshore> listaProjetos = new ArrayList<>();
    private List<Funcionario> listaFuncionarios = new ArrayList<>();
    private List<EtapaProjeto> listaEtapas = new ArrayList<>();

    private boolean modoEdicao = false;

    public CadastroEtapaProjetoFrame() {
        super("Cadastro de Etapas de Projeto", true, true, true, true);
        etapaDAO = new EtapaProjetoDAO();
        projetoDAO = new ProjetoOffshoreDAO();
        funcionarioDAO = new FuncionarioDAO();

        inicializarComponentes();
        carregarProjetosCombo();
        carregarFuncionariosCombo();
        carregarEtapas();
        habilitarCampos(false);
    }

    private void inicializarComponentes() {
        setSize(950, 550);
        setLayout(new BorderLayout(10, 10));

        JPanel painelForm = new JPanel(new GridBagLayout());
        painelForm.setBorder(BorderFactory.createTitledBorder("Dados da Etapa"));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(4,4,4,4);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel lblId = new JLabel("ID:");
        JLabel lblProjeto = new JLabel("Projeto:");
        JLabel lblResponsavel = new JLabel("Responsável:");
        JLabel lblNomeEtapa = new JLabel("Nome da Etapa:");
        JLabel lblDataPrevIni = new JLabel("Prev. Início (AAAA-MM-DD):");
        JLabel lblDataPrevFim = new JLabel("Prev. Fim (AAAA-MM-DD):");
        JLabel lblDataConc = new JLabel("Conclusão (AAAA-MM-DD):");
        JLabel lblStatus = new JLabel("Status:");
        JLabel lblObs = new JLabel("Observação:");

        txtId = new JTextField(5);
        txtId.setEditable(false);

        cbProjeto = new JComboBox<>();
        cbResponsavel = new JComboBox<>();

        txtNomeEtapa = new JTextField(30);
        txtDataPrevistaInicio = new JTextField(10);
        txtDataPrevistaFim = new JTextField(10);
        txtDataConclusao = new JTextField(10);

        cbStatus = new JComboBox<>(new String[]{
                "Selecione...",
                "Pendente",
                "Em andamento",
                "Aguardando recursos",
                "Concluída",
                "Cancelada"
        });

        txtObservacao = new JTextArea(4, 30);
        txtObservacao.setLineWrap(true);
        txtObservacao.setWrapStyleWord(true);
        JScrollPane scrollObs = new JScrollPane(txtObservacao);
        JPanel painelObs = new JPanel(new BorderLayout());
        painelObs.setBorder(BorderFactory.createTitledBorder("Observações da Etapa"));
        painelObs.add(scrollObs, BorderLayout.CENTER);

        int y = 0;

        // Linha 0 - ID
        gbc.gridx=0; gbc.gridy=y; gbc.weightx=0;
        painelForm.add(lblId, gbc);
        gbc.gridx=1; gbc.weightx=1;
        painelForm.add(txtId, gbc);

        // Linha 1 - Projeto
        y++;
        gbc.gridx=0; gbc.gridy=y; gbc.weightx=0;
        painelForm.add(lblProjeto, gbc);
        gbc.gridx=1; gbc.weightx=1;
        painelForm.add(cbProjeto, gbc);

        // Linha 2 - Responsável
        y++;
        gbc.gridx=0; gbc.gridy=y; gbc.weightx=0;
        painelForm.add(lblResponsavel, gbc);
        gbc.gridx=1; gbc.weightx=1;
        painelForm.add(cbResponsavel, gbc);

        // Linha 3 - Nome Etapa
        y++;
        gbc.gridx=0; gbc.gridy=y; gbc.weightx=0;
        painelForm.add(lblNomeEtapa, gbc);
        gbc.gridx=1; gbc.weightx=1;
        painelForm.add(txtNomeEtapa, gbc);

        // Linha 4 - Datas previstas
        y++;
        gbc.gridx=0; gbc.gridy=y; gbc.weightx=0;
        painelForm.add(lblDataPrevIni, gbc);
        gbc.gridx=1; gbc.weightx=1;
        painelForm.add(txtDataPrevistaInicio, gbc);

        y++;
        gbc.gridx=0; gbc.gridy=y; gbc.weightx=0;
        painelForm.add(lblDataPrevFim, gbc);
        gbc.gridx=1; gbc.weightx=1;
        painelForm.add(txtDataPrevistaFim, gbc);

        // Linha 6 - Data Conclusão
        y++;
        gbc.gridx=0; gbc.gridy=y; gbc.weightx=0;
        painelForm.add(lblDataConc, gbc);
        gbc.gridx=1; gbc.weightx=1;
        painelForm.add(txtDataConclusao, gbc);

        // Linha 7 - Status
        y++;
        gbc.gridx=0; gbc.gridy=y; gbc.weightx=0;
        painelForm.add(lblStatus, gbc);
        gbc.gridx=1; gbc.weightx=1;
        painelForm.add(cbStatus, gbc);

        // Linha 8 - Observação
        y++;
        gbc.gridx=0; gbc.gridy=y; gbc.weightx=0;
        painelForm.add(lblObs, gbc);
        gbc.gridx=1; gbc.weightx=1;
        painelForm.add(painelObs, gbc);

        // Botões
        JPanel painelBotoes = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        btnNovo = new JButton("Novo");
        btnEditar = new JButton("Editar");
        btnSalvar = new JButton("Salvar");
        btnExcluir = new JButton("Excluir");
        btnCancelar = new JButton("Cancelar");
        btnAtualizar = new JButton("Atualizar Lista");

        btnSalvar.setEnabled(false);
        btnCancelar.setEnabled(false);

        painelBotoes.add(btnNovo);
        painelBotoes.add(btnEditar);
        painelBotoes.add(btnSalvar);
        painelBotoes.add(btnExcluir);
        painelBotoes.add(btnCancelar);
        painelBotoes.add(btnAtualizar);

        // Tabela
        modelo = new DefaultTableModel(
                new Object[]{
                        "ID", "Projeto", "Responsável", "Nome Etapa",
                        "Status", "Prev. Início", "Prev. Fim", "Conclusão"
                }, 0
        ) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        tabela = new JTable(modelo);
        JScrollPane scrollTabela = new JScrollPane(tabela);
        scrollTabela.setBorder(BorderFactory.createTitledBorder("Etapas cadastradas"));

        JPanel topo = new JPanel(new BorderLayout());
        topo.add(painelForm, BorderLayout.CENTER);
        topo.add(painelBotoes, BorderLayout.SOUTH);

        add(topo, BorderLayout.NORTH);
        add(scrollTabela, BorderLayout.CENTER);

        // AÇÕES
        btnNovo.addActionListener(e -> novo());
        btnEditar.addActionListener(e -> editar());
        btnSalvar.addActionListener(e -> salvar());
        btnExcluir.addActionListener(e -> excluir());
        btnCancelar.addActionListener(e -> cancelar());
        btnAtualizar.addActionListener(e -> carregarEtapas());

        tabela.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int linha = tabela.getSelectedRow();
                carregarDaTabela(linha);
            }
        });
    }

    private void habilitarCampos(boolean ativo) {
        cbProjeto.setEnabled(ativo);
        cbResponsavel.setEnabled(ativo);
        txtNomeEtapa.setEnabled(ativo);
        txtDataPrevistaInicio.setEnabled(ativo);
        txtDataPrevistaFim.setEnabled(ativo);
        txtDataConclusao.setEnabled(ativo);
        cbStatus.setEnabled(ativo);
        txtObservacao.setEnabled(ativo);
    }

    private void limparCampos() {
        txtId.setText("");
        cbProjeto.setSelectedIndex(0);
        cbResponsavel.setSelectedIndex(0);
        txtNomeEtapa.setText("");
        txtDataPrevistaInicio.setText("");
        txtDataPrevistaFim.setText("");
        txtDataConclusao.setText("");
        cbStatus.setSelectedIndex(0);
        txtObservacao.setText("");
        tabela.clearSelection();
    }

    private void novo() {
        modoEdicao = false;
        limparCampos();
        habilitarCampos(true);
        btnSalvar.setEnabled(true);
        btnCancelar.setEnabled(true);
    }

    private void editar() {
        if (txtId.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Selecione uma etapa para editar.");
            return;
        }
        modoEdicao = true;
        habilitarCampos(true);
        btnSalvar.setEnabled(true);
        btnCancelar.setEnabled(true);
    }

    private void salvar() {
        int idxProj = cbProjeto.getSelectedIndex();
        int idxResp = cbResponsavel.getSelectedIndex();

        if (idxProj <= 0) {
            JOptionPane.showMessageDialog(this, "Selecione um Projeto.");
            return;
        }
        if (idxResp <= 0) {
            JOptionPane.showMessageDialog(this, "Selecione um Responsável.");
            return;
        }
        String nomeEtapa = txtNomeEtapa.getText().trim();
        if (nomeEtapa.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Informe o Nome da Etapa.");
            return;
        }
        if (cbStatus.getSelectedIndex() == 0) {
            JOptionPane.showMessageDialog(this, "Selecione o Status da Etapa.");
            return;
        }

        EtapaProjeto e = new EtapaProjeto();

        if (modoEdicao) {
            e.setIdEtapa(Integer.parseInt(txtId.getText()));
        }

        // Projeto
        ProjetoOffshore proj = listaProjetos.get(idxProj - 1);
        e.setIdProjeto(proj.getIdProjeto());

        // Responsável: vamos gravar o NOME (campo texto)
        Funcionario f = listaFuncionarios.get(idxResp - 1);
        e.setResponsavelEtapa(f.getNome());

        e.setNomeEtapa(nomeEtapa);
        e.setStatusEtapa(cbStatus.getSelectedItem().toString());
        e.setObservacao(txtObservacao.getText().trim());

        String dPrevIni = txtDataPrevistaInicio.getText().trim();
        String dPrevFim = txtDataPrevistaFim.getText().trim();
        String dConc = txtDataConclusao.getText().trim();

        try {
            e.setDataPrevistaInicio(dPrevIni.isEmpty() ? null : Date.valueOf(dPrevIni));
            e.setDataPrevistaFim(dPrevFim.isEmpty() ? null : Date.valueOf(dPrevFim));
            e.setDataConclusao(dConc.isEmpty() ? null : Date.valueOf(dConc));
        } catch (IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(this,
                    "Alguma data está em formato inválido. Use AAAA-MM-DD.",
                    "Data inválida",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        try {
            if (modoEdicao) {
                etapaDAO.atualizar(e);
                JOptionPane.showMessageDialog(this, "Etapa atualizada com sucesso.");
            } else {
                etapaDAO.inserir(e);
                JOptionPane.showMessageDialog(this, "Etapa inserida com sucesso.");
            }
            carregarEtapas();
            cancelar();
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this,
                    "Erro ao salvar etapa: " + ex.getMessage(),
                    "Erro",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    private void excluir() {
        if (txtId.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Selecione uma etapa para excluir.");
            return;
        }
        int op = JOptionPane.showConfirmDialog(this,
                "Deseja realmente excluir esta etapa?",
                "Excluir",
                JOptionPane.YES_NO_OPTION);

        if (op == JOptionPane.YES_OPTION) {
            try {
                int id = Integer.parseInt(txtId.getText());
                etapaDAO.deletar(id);
                JOptionPane.showMessageDialog(this, "Etapa excluída com sucesso.");
                carregarEtapas();
                limparCampos();
            } catch (Exception ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(this,
                        "Erro ao excluir etapa: " + ex.getMessage(),
                        "Erro",
                        JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void cancelar() {
        limparCampos();
        habilitarCampos(false);
        btnSalvar.setEnabled(false);
        btnCancelar.setEnabled(false);
        modoEdicao = false;
    }

    private void carregarProjetosCombo() {
        cbProjeto.removeAllItems();
        listaProjetos.clear();
        cbProjeto.addItem("Selecione...");

        try {
            listaProjetos = projetoDAO.listarTodos();
            for (ProjetoOffshore p : listaProjetos) {
                cbProjeto.addItem(p.getIdProjeto() + " - " + p.getNomeProjeto());
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this,
                    "Erro ao carregar projetos: " + ex.getMessage(),
                    "Erro",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    private void carregarFuncionariosCombo() {
        cbResponsavel.removeAllItems();
        listaFuncionarios.clear();
        cbResponsavel.addItem("Selecione...");

        try {
            List<Funcionario> lista = funcionarioDAO.listarTodos();
            for (Funcionario f : lista) {
                if (f.isAtivo()) {
                    listaFuncionarios.add(f);
                    cbResponsavel.addItem(f.getIdFuncionario() + " - " + f.getNome());
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this,
                    "Erro ao carregar funcionários: " + ex.getMessage(),
                    "Erro",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    private void carregarEtapas() {
        modelo.setRowCount(0);
        listaEtapas.clear();

        try {
            listaEtapas = etapaDAO.listarTodas();
            for (EtapaProjeto e : listaEtapas) {
                String nomeProj = buscarNomeProjeto(e.getIdProjeto());

                modelo.addRow(new Object[]{
                        e.getIdEtapa(),
                        nomeProj,
                        e.getResponsavelEtapa(),
                        e.getNomeEtapa(),
                        e.getStatusEtapa(),
                        e.getDataPrevistaInicio() != null ? e.getDataPrevistaInicio().toString() : "",
                        e.getDataPrevistaFim() != null ? e.getDataPrevistaFim().toString() : "",
                        e.getDataConclusao() != null ? e.getDataConclusao().toString() : ""
                });
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this,
                    "Erro ao carregar etapas: " + ex.getMessage(),
                    "Erro",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    private String buscarNomeProjeto(int idProj) {
        for (ProjetoOffshore p : listaProjetos) {
            if (p.getIdProjeto() == idProj) {
                return p.getNomeProjeto();
            }
        }
        return "-";
    }

    private void carregarDaTabela(int linha) {
        if (linha < 0 || linha >= listaEtapas.size()) return;

        EtapaProjeto e = listaEtapas.get(linha);

        txtId.setText(String.valueOf(e.getIdEtapa()));
        txtNomeEtapa.setText(e.getNomeEtapa());
        txtDataPrevistaInicio.setText(e.getDataPrevistaInicio() != null ? e.getDataPrevistaInicio().toString() : "");
        txtDataPrevistaFim.setText(e.getDataPrevistaFim() != null ? e.getDataPrevistaFim().toString() : "");
        txtDataConclusao.setText(e.getDataConclusao() != null ? e.getDataConclusao().toString() : "");
        cbStatus.setSelectedItem(e.getStatusEtapa());
        txtObservacao.setText(e.getObservacao() != null ? e.getObservacao() : "");

        // Selecionar Projeto no combo
        int idxProj = 0;
        for (int i = 0; i < listaProjetos.size(); i++) {
            if (listaProjetos.get(i).getIdProjeto() == e.getIdProjeto()) {
                idxProj = i + 1; // +1 por conta do "Selecione..."
                break;
            }
        }
        cbProjeto.setSelectedIndex(idxProj);

        // Selecionar Responsável (por nome)
        int idxResp = 0;
        for (int i = 0; i < listaFuncionarios.size(); i++) {
            if (listaFuncionarios.get(i).getNome().equals(e.getResponsavelEtapa())) {
                idxResp = i + 1;
                break;
            }
        }
        cbResponsavel.setSelectedIndex(idxResp);

        habilitarCampos(false);
        btnSalvar.setEnabled(false);
        btnCancelar.setEnabled(false);
        modoEdicao = false;
    }
}
