package sisoff.view;

import sisoff.dao.ProjetoOffshoreDAO;
import sisoff.dao.AtivoOffshoreDAO;
import sisoff.dao.FuncionarioDAO;
import sisoff.model.ProjetoOffshore;
import sisoff.model.AtivoOffshore;
import sisoff.model.Funcionario;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class RelatorioProjetosStatusFrame extends JInternalFrame {

    private JComboBox<String> cbStatus;
    private JButton btnFiltrar;
    private JButton btnLimpar;
    private JTable tabela;
    private DefaultTableModel modelo;

    private ProjetoOffshoreDAO projetoDAO;
    private AtivoOffshoreDAO ativoDAO;
    private FuncionarioDAO funcionarioDAO;

    private List<ProjetoOffshore> listaProjetos = new ArrayList<>();
    private List<AtivoOffshore> listaAtivos = new ArrayList<>();
    private List<Funcionario> listaFuncionarios = new ArrayList<>();

    public RelatorioProjetosStatusFrame() {
        super("Relatório - Projetos por Status", true, true, true, true);

        projetoDAO = new ProjetoOffshoreDAO();
        ativoDAO = new AtivoOffshoreDAO();
        funcionarioDAO = new FuncionarioDAO();

        inicializarComponentes();
        carregarAtivos();
        carregarFuncionarios();
        carregarProjetos(); // carrega todos inicialmente
    }

    private void inicializarComponentes() {
        setSize(900, 550);
        setLayout(new BorderLayout(10, 10));

        // Painel de filtros
        JPanel painelFiltro = new JPanel(new FlowLayout(FlowLayout.LEFT));
        painelFiltro.setBorder(BorderFactory.createTitledBorder("Filtro"));

        JLabel lblStatus = new JLabel("Status do Projeto:");

        cbStatus = new JComboBox<>(new String[]{
                "Todos",
                "Planejado",
                "Em andamento",
                "Concluído",
                "Cancelado",
                "Suspenso"
        });

        btnFiltrar = new JButton("Filtrar");
        btnLimpar = new JButton("Limpar");

        painelFiltro.add(lblStatus);
        painelFiltro.add(cbStatus);
        painelFiltro.add(btnFiltrar);
        painelFiltro.add(btnLimpar);

        // Tabela
        modelo = new DefaultTableModel(
                new Object[]{
                        "ID", "Ativo", "Nome do Projeto",
                        "Tipo", "Data Início", "Data Fim Prevista",
                        "Status", "Responsável"
                }, 0
        ) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        tabela = new JTable(modelo);
        JScrollPane scrollTabela = new JScrollPane(tabela);
        scrollTabela.setBorder(BorderFactory.createTitledBorder("Projetos"));

        add(painelFiltro, BorderLayout.NORTH);
        add(scrollTabela, BorderLayout.CENTER);

        // Eventos
        btnFiltrar.addActionListener(e -> aplicarFiltro());
        btnLimpar.addActionListener(e -> limparFiltro());
    }

    private void carregarAtivos() {
        try {
            listaAtivos = ativoDAO.listarTodos();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                    "Erro ao carregar ativos: " + e.getMessage(),
                    "Erro",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    private void carregarFuncionarios() {
        try {
            listaFuncionarios = funcionarioDAO.listarTodos();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                    "Erro ao carregar funcionários: " + e.getMessage(),
                    "Erro",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    private void carregarProjetos() {
        modelo.setRowCount(0);
        listaProjetos.clear();

        try {
            listaProjetos = projetoDAO.listarTodos();

            for (ProjetoOffshore p : listaProjetos) {
                String nomeAtivo = buscarNomeAtivo(p.getIdAtivo());
                String nomeResp = buscarNomeResponsavel(p.getIdResponsavel());

                modelo.addRow(new Object[]{
                        p.getIdProjeto(),
                        nomeAtivo,
                        p.getNomeProjeto(),
                        p.getTipoProjeto(),
                        p.getDataInicio() != null ? p.getDataInicio().toString() : "",
                        p.getDataFimPrevista() != null ? p.getDataFimPrevista().toString() : "",
                        p.getStatus(),
                        nomeResp
                });
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                    "Erro ao carregar projetos: " + e.getMessage(),
                    "Erro",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    private void aplicarFiltro() {
        String status = cbStatus.getSelectedItem().toString();

        modelo.setRowCount(0); // limpa tabela

        for (ProjetoOffshore p : listaProjetos) {

            if (!status.equals("Todos") && !p.getStatus().equalsIgnoreCase(status)) {
                continue; // pula se não bater o status
            }

            String nomeAtivo = buscarNomeAtivo(p.getIdAtivo());
            String nomeResp = buscarNomeResponsavel(p.getIdResponsavel());

            modelo.addRow(new Object[]{
                    p.getIdProjeto(),
                    nomeAtivo,
                    p.getNomeProjeto(),
                    p.getTipoProjeto(),
                    p.getDataInicio() != null ? p.getDataInicio().toString() : "",
                    p.getDataFimPrevista() != null ? p.getDataFimPrevista().toString() : "",
                    p.getStatus(),
                    nomeResp
            });
        }
    }

    private void limparFiltro() {
        cbStatus.setSelectedIndex(0); // "Todos"
        carregarProjetos();
    }

    private String buscarNomeAtivo(int idAtivo) {
        for (AtivoOffshore a : listaAtivos) {
            if (a.getIdAtivo() == idAtivo) {
                return a.getNomeAtivo();
            }
        }
        return "-";
    }

    private String buscarNomeResponsavel(Integer idResp) {
        if (idResp == null) return "-";
        for (Funcionario f : listaFuncionarios) {
            if (f.getIdFuncionario() == idResp) {
                return f.getNome();
            }
        }
        return "-";
    }
}
