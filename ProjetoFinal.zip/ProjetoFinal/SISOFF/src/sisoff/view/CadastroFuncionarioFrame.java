package sisoff.view;

import sisoff.dao.FuncionarioDAO;
import sisoff.model.Funcionario;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.List;

public class CadastroFuncionarioFrame extends JInternalFrame {

    private JTextField txtId;
    private JTextField txtNome;
    private JTextField txtUsuario;
    private JPasswordField txtSenha;
    private JTextField txtCargo;
    private JCheckBox chkAtivo;

    private JButton btnNovo;
    private JButton btnEditar;
    private JButton btnSalvar;
    private JButton btnExcluir;
    private JButton btnCancelar;
    private JButton btnAtualizar;

    private JTable tabela;
    private DefaultTableModel modelo;

    private FuncionarioDAO funcionarioDAO;

    private boolean modoEdicao = false;  // TRUE = editando / FALSE = novo

    public CadastroFuncionarioFrame() {
        super("Cadastro de Funcionários", true, true, true, true);
        funcionarioDAO = new FuncionarioDAO();
        inicializarComponentes();
        carregarFuncionarios();
        habilitarCampos(false);
    }

    private void inicializarComponentes() {
        setSize(700, 420);
        setLayout(new BorderLayout(10, 10));

        JPanel painelForm = new JPanel(new GridBagLayout());
        painelForm.setBorder(BorderFactory.createTitledBorder("Dados do Funcionário"));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(4, 4, 4, 4);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel lblId = new JLabel("ID:");
        JLabel lblNome = new JLabel("Nome:");
        JLabel lblUsuario = new JLabel("Usuário:");
        JLabel lblSenha = new JLabel("Senha:");
        JLabel lblCargo = new JLabel("Cargo:");

        txtId = new JTextField(5);
        txtId.setEditable(false);
        txtNome = new JTextField(25);
        txtUsuario = new JTextField(15);
        txtSenha = new JPasswordField(15);
        txtCargo = new JTextField(15);
        chkAtivo = new JCheckBox("Ativo");
        chkAtivo.setSelected(true);

        // Linha 0
        gbc.gridx = 0; gbc.gridy = 0; painelForm.add(lblId, gbc);
        gbc.gridx = 1; painelForm.add(txtId, gbc);

        // Linha 1
        gbc.gridx = 0; gbc.gridy = 1; painelForm.add(lblNome, gbc);
        gbc.gridx = 1; painelForm.add(txtNome, gbc);

        // Linha 2
        gbc.gridx = 0; gbc.gridy = 2; painelForm.add(lblUsuario, gbc);
        gbc.gridx = 1; painelForm.add(txtUsuario, gbc);

        // Linha 3
        gbc.gridx = 0; gbc.gridy = 3; painelForm.add(lblSenha, gbc);
        gbc.gridx = 1; painelForm.add(txtSenha, gbc);

        // Linha 4
        gbc.gridx = 0; gbc.gridy = 4; painelForm.add(lblCargo, gbc);
        gbc.gridx = 1; painelForm.add(txtCargo, gbc);
        gbc.gridx = 2; painelForm.add(chkAtivo, gbc);

        // Painel de botões
        JPanel painelBotoes = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        btnNovo = new JButton("Novo");
        btnEditar = new JButton("Editar");
        btnSalvar = new JButton("Salvar");
        btnExcluir = new JButton("Excluir");
        btnCancelar = new JButton("Cancelar");
        btnAtualizar = new JButton("Atualizar");

        btnSalvar.setEnabled(false);
        btnCancelar.setEnabled(false);

        painelBotoes.add(btnNovo);
        painelBotoes.add(btnEditar);
        painelBotoes.add(btnSalvar);
        painelBotoes.add(btnExcluir);
        painelBotoes.add(btnCancelar);
        painelBotoes.add(btnAtualizar);

        // Tabela
        modelo = new DefaultTableModel(
                new Object[]{"ID", "Nome", "Usuário", "Cargo", "Ativo"}, 0
        ) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        tabela = new JTable(modelo);
        JScrollPane scroll = new JScrollPane(tabela);

        JPanel topo = new JPanel(new BorderLayout());
        topo.add(painelForm, BorderLayout.CENTER);
        topo.add(painelBotoes, BorderLayout.SOUTH);

        add(topo, BorderLayout.NORTH);
        add(scroll, BorderLayout.CENTER);

        // AÇÕES
        btnNovo.addActionListener(e -> novoRegistro());
        btnEditar.addActionListener(e -> editarRegistro());
        btnSalvar.addActionListener(e -> salvar());
        btnExcluir.addActionListener(e -> excluir());
        btnCancelar.addActionListener(e -> cancelar());
        btnAtualizar.addActionListener(e -> carregarFuncionarios());

        tabela.addMouseListener(new MouseAdapter() {
            @Override public void mouseClicked(MouseEvent e) {
                int linha = tabela.getSelectedRow();
                carregarDaTabela(linha);
            }
        });
    }

    private void habilitarCampos(boolean ativo) {
        txtNome.setEnabled(ativo);
        txtUsuario.setEnabled(ativo);
        txtSenha.setEnabled(ativo);
        txtCargo.setEnabled(ativo);
        chkAtivo.setEnabled(ativo);
    }

    private void novoRegistro() {
        modoEdicao = false;
        limparCampos();
        habilitarCampos(true);
        btnSalvar.setEnabled(true);
        btnCancelar.setEnabled(true);
    }

    private void editarRegistro() {
        if (txtId.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Selecione um funcionário.");
            return;
        }
        modoEdicao = true;
        habilitarCampos(true);
        btnSalvar.setEnabled(true);
        btnCancelar.setEnabled(true);
    }

    private void salvar() {
        String nome = txtNome.getText().trim();
        String usuario = txtUsuario.getText().trim();
        String senha = new String(txtSenha.getPassword()).trim();

        if (nome.isEmpty() || usuario.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Preencha os campos obrigatórios.");
            return;
        }

        Funcionario f = new Funcionario();

        if (modoEdicao) f.setIdFuncionario(Integer.parseInt(txtId.getText()));

        f.setNome(nome);
        f.setUsuario(usuario);
        f.setCargo(txtCargo.getText());
        f.setAtivo(chkAtivo.isSelected());

        if (!senha.isEmpty()) {
            f.setSenha(senha);
        } else if (modoEdicao) {
            f.setSenha(funcionarioDAO.buscarPorId(f.getIdFuncionario()).getSenha());
        } else {
            JOptionPane.showMessageDialog(this, "Senha é obrigatória no cadastro novo.");
            return;
        }

        try {
            if (modoEdicao) funcionarioDAO.atualizar(f);
            else funcionarioDAO.inserir(f);

            JOptionPane.showMessageDialog(this, "Salvo com sucesso!");
            carregarFuncionarios();
            cancelar();

        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Erro: " + ex.getMessage());
        }
    }

    private void excluir() {
        if (txtId.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Selecione um funcionário.");
            return;
        }

        int op = JOptionPane.showConfirmDialog(this, "Excluir funcionário?");
        if (op == JOptionPane.YES_OPTION) {
            funcionarioDAO.deletar(Integer.parseInt(txtId.getText()));
            carregarFuncionarios();
            limparCampos();
        }
    }

    private void cancelar() {
        limparCampos();
        habilitarCampos(false);
        btnSalvar.setEnabled(false);
        btnCancelar.setEnabled(false);
    }

    private void carregarFuncionarios() {
        modelo.setRowCount(0);
        for (Funcionario f : funcionarioDAO.listarTodos()) {
            modelo.addRow(new Object[]{
                    f.getIdFuncionario(),
                    f.getNome(),
                    f.getUsuario(),
                    f.getCargo(),
                    f.isAtivo() ? "Sim" : "Não"
            });
        }
    }

    private void carregarDaTabela(int linha) {
        txtId.setText(modelo.getValueAt(linha, 0).toString());
        txtNome.setText(modelo.getValueAt(linha, 1).toString());
        txtUsuario.setText(modelo.getValueAt(linha, 2).toString());
        txtCargo.setText(modelo.getValueAt(linha, 3).toString());
        chkAtivo.setSelected(modelo.getValueAt(linha, 4).equals("Sim"));
        txtSenha.setText("");
        habilitarCampos(false);
    }

    private void limparCampos() {
        txtId.setText("");
        txtNome.setText("");
        txtUsuario.setText("");
        txtSenha.setText("");
        txtCargo.setText("");
        chkAtivo.setSelected(true);
        tabela.clearSelection();
    }
}


