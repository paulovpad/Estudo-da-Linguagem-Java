package sisoff.view;

import sisoff.dao.AtivoOffshoreDAO;
import sisoff.dao.FuncionarioDAO;
import sisoff.dao.ProjetoOffshoreDAO;
import sisoff.model.AtivoOffshore;
import sisoff.model.Funcionario;
import sisoff.model.ProjetoOffshore;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

public class CadastroProjetoOffshoreFrame extends JInternalFrame {

    // Campos
    private JTextField txtId;
    private JComboBox<String> cbAtivo;
    private JComboBox<String> cbResponsavel;
    private JTextField txtNomeProjeto;
    private JComboBox<String> cbTipoProjeto;
    private JTextField txtDataInicio;
    private JTextField txtDataFimPrevista;
    private JComboBox<String> cbStatus;
    private JTextArea txtDescricao;

    // Botões
    private JButton btnNovo;
    private JButton btnEditar;
    private JButton btnSalvar;
    private JButton btnExcluir;
    private JButton btnCancelar;
    private JButton btnAtualizar;

    // Tabela
    private JTable tabela;
    private DefaultTableModel modelo;

    // DAOs
    private ProjetoOffshoreDAO projetoDAO;
    private AtivoOffshoreDAO ativoDAO;
    private FuncionarioDAO funcionarioDAO;

    // Listas auxiliares
    private List<AtivoOffshore> listaAtivos = new ArrayList<>();
    private List<Funcionario> listaFuncionarios = new ArrayList<>();
    private List<ProjetoOffshore> listaProjetos = new ArrayList<>();

    private boolean modoEdicao = false;

    public CadastroProjetoOffshoreFrame() {
        super("Cadastro de Projetos Offshore", true, true, true, true);
        projetoDAO = new ProjetoOffshoreDAO();
        ativoDAO = new AtivoOffshoreDAO();
        funcionarioDAO = new FuncionarioDAO();

        inicializarComponentes();
        carregarAtivos();
        carregarFuncionarios();
        carregarProjetos();
        habilitarCampos(false);
    }

    private void inicializarComponentes() {
        setSize(950, 550);
        setLayout(new BorderLayout(10, 10));

        // Painel de formulário
        JPanel painelForm = new JPanel(new GridBagLayout());
        painelForm.setBorder(BorderFactory.createTitledBorder("Dados do Projeto Offshore"));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(4, 4, 4, 4);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel lblId = new JLabel("ID:");
        JLabel lblAtivo = new JLabel("Ativo Offshore:");
        JLabel lblResponsavel = new JLabel("Responsável:");
        JLabel lblNomeProj = new JLabel("Nome do Projeto:");
        JLabel lblTipoProj = new JLabel("Tipo do Projeto:");
        JLabel lblDataInicio = new JLabel("Data Início (AAAA-MM-DD):");
        JLabel lblDataFim = new JLabel("Data Fim Prevista (AAAA-MM-DD):");
        JLabel lblStatus = new JLabel("Status:");
        JLabel lblDescricao = new JLabel("Descrição / Escopo:");

        txtId = new JTextField(5);
        txtId.setEditable(false);

        cbAtivo = new JComboBox<>();
        cbResponsavel = new JComboBox<>();

        txtNomeProjeto = new JTextField(30);

        cbTipoProjeto = new JComboBox<>(new String[]{
                "Selecione...",
                "Manutenção",
                "Inspeção",
                "Intervenção Submarina",
                "Campanha Submarina",
                "Mobilização",
                "Desmobilização",
                "Comissionamento",
                "Documentação Técnica",
                "Modificação",
                "Outros"
        });

        txtDataInicio = new JTextField(10);
        txtDataFimPrevista = new JTextField(10);

        cbStatus = new JComboBox<>(new String[]{
                "Selecione...",
                "Planejado",
                "Em andamento",
                "Aguardando recursos",
                "Suspenso",
                "Concluído",
                "Cancelado"
        });

        txtDescricao = new JTextArea(4, 30);
        txtDescricao.setLineWrap(true);
        txtDescricao.setWrapStyleWord(true);
        JScrollPane scrollDesc = new JScrollPane(txtDescricao);
        JPanel painelDescricao = new JPanel(new BorderLayout());
        painelDescricao.setBorder(BorderFactory.createTitledBorder("Descrição / Observações do Projeto"));
        painelDescricao.add(scrollDesc, BorderLayout.CENTER);

        int y = 0;

        // Linha 0 - ID
        gbc.gridx = 0; gbc.gridy = y; gbc.weightx = 0;
        painelForm.add(lblId, gbc);
        gbc.gridx = 1; gbc.weightx = 1;
        painelForm.add(txtId, gbc);

        // Linha 1 - Ativo
        y++;
        gbc.gridx = 0; gbc.gridy = y; gbc.weightx = 0;
        painelForm.add(lblAtivo, gbc);
        gbc.gridx = 1; gbc.weightx = 1;
        painelForm.add(cbAtivo, gbc);

        // Linha 2 - Responsável
        y++;
        gbc.gridx = 0; gbc.gridy = y; gbc.weightx = 0;
        painelForm.add(lblResponsavel, gbc);
        gbc.gridx = 1; gbc.weightx = 1;
        painelForm.add(cbResponsavel, gbc);

        // Linha 3 - Nome do Projeto
        y++;
        gbc.gridx = 0; gbc.gridy = y; gbc.weightx = 0;
        painelForm.add(lblNomeProj, gbc);
        gbc.gridx = 1; gbc.weightx = 1;
        painelForm.add(txtNomeProjeto, gbc);

        // Linha 4 - Tipo do Projeto
        y++;
        gbc.gridx = 0; gbc.gridy = y; gbc.weightx = 0;
        painelForm.add(lblTipoProj, gbc);
        gbc.gridx = 1; gbc.weightx = 1;
        painelForm.add(cbTipoProjeto, gbc);

        // Linha 5 - Data Início
        y++;
        gbc.gridx = 0; gbc.gridy = y; gbc.weightx = 0;
        painelForm.add(lblDataInicio, gbc);
        gbc.gridx = 1; gbc.weightx = 1;
        painelForm.add(txtDataInicio, gbc);

        // Linha 6 - Data Fim Prevista
        y++;
        gbc.gridx = 0; gbc.gridy = y; gbc.weightx = 0;
        painelForm.add(lblDataFim, gbc);
        gbc.gridx = 1; gbc.weightx = 1;
        painelForm.add(txtDataFimPrevista, gbc);

        // Linha 7 - Status
        y++;
        gbc.gridx = 0; gbc.gridy = y; gbc.weightx = 0;
        painelForm.add(lblStatus, gbc);
        gbc.gridx = 1; gbc.weightx = 1;
        painelForm.add(cbStatus, gbc);

        // Linha 8 - Descrição (painel)
        y++;
        gbc.gridx = 0; gbc.gridy = y; gbc.weightx = 0;
        painelForm.add(lblDescricao, gbc);
        gbc.gridx = 1; gbc.weightx = 1;
        painelForm.add(painelDescricao, gbc);

        // Painel de botões
        JPanel painelBotoes = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        btnNovo = new JButton("Novo");
        btnEditar = new JButton("Editar");
        btnSalvar = new JButton("Salvar");
        btnExcluir = new JButton("Excluir");
        btnCancelar = new JButton("Cancelar");
        btnAtualizar = new JButton("Atualizar Lista");

        btnSalvar.setEnabled(false);
        btnCancelar.setEnabled(false);

        painelBotoes.add(btnNovo);
        painelBotoes.add(btnEditar);
        painelBotoes.add(btnSalvar);
        painelBotoes.add(btnExcluir);
        painelBotoes.add(btnCancelar);
        painelBotoes.add(btnAtualizar);

        // Tabela
        modelo = new DefaultTableModel(
                new Object[]{
                        "ID", "Ativo", "Responsável", "Nome do Projeto",
                        "Tipo", "Status", "Início", "Fim Prevista"
                }, 0
        ) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        tabela = new JTable(modelo);
        JScrollPane scrollTabela = new JScrollPane(tabela);
        scrollTabela.setBorder(BorderFactory.createTitledBorder("Projetos cadastrados"));

        // Montagem do topo
        JPanel topo = new JPanel(new BorderLayout());
        topo.add(painelForm, BorderLayout.CENTER);
        topo.add(painelBotoes, BorderLayout.SOUTH);

        add(topo, BorderLayout.NORTH);
        add(scrollTabela, BorderLayout.CENTER);

        // AÇÕES
        btnNovo.addActionListener(e -> novo());
        btnEditar.addActionListener(e -> editar());
        btnSalvar.addActionListener(e -> salvar());
        btnExcluir.addActionListener(e -> excluir());
        btnCancelar.addActionListener(e -> cancelar());
        btnAtualizar.addActionListener(e -> carregarProjetos());

        tabela.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int linha = tabela.getSelectedRow();
                carregarDaTabela(linha);
            }
        });
    }

    // ================= HABILITAR / DESABILITAR ===================

    private void habilitarCampos(boolean ativo) {
        cbAtivo.setEnabled(ativo);
        cbResponsavel.setEnabled(ativo);
        txtNomeProjeto.setEnabled(ativo);
        cbTipoProjeto.setEnabled(ativo);
        txtDataInicio.setEnabled(ativo);
        txtDataFimPrevista.setEnabled(ativo);
        cbStatus.setEnabled(ativo);
        txtDescricao.setEnabled(ativo);
    }

    private void limparCampos() {
        txtId.setText("");
        cbAtivo.setSelectedIndex(0);
        cbResponsavel.setSelectedIndex(0);
        txtNomeProjeto.setText("");
        cbTipoProjeto.setSelectedIndex(0);
        txtDataInicio.setText("");
        txtDataFimPrevista.setText("");
        cbStatus.setSelectedIndex(0);
        txtDescricao.setText("");
        tabela.clearSelection();
    }

    // ================= BOTÕES ===================

    private void novo() {
        modoEdicao = false;
        limparCampos();
        habilitarCampos(true);
        btnSalvar.setEnabled(true);
        btnCancelar.setEnabled(true);
    }

    private void editar() {
        if (txtId.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Selecione um projeto para editar.");
            return;
        }
        modoEdicao = true;
        habilitarCampos(true);
        btnSalvar.setEnabled(true);
        btnCancelar.setEnabled(true);
    }

    private void salvar() {
        // Validações básicas
        int idxAtivo = cbAtivo.getSelectedIndex();
        int idxResp = cbResponsavel.getSelectedIndex();

        if (idxAtivo <= 0) {
            JOptionPane.showMessageDialog(this, "Selecione um Ativo Offshore.");
            return;
        }
        if (idxResp <= 0) {
            JOptionPane.showMessageDialog(this, "Selecione um Responsável pelo projeto.");
            return;
        }
        String nomeProj = txtNomeProjeto.getText().trim();
        if (nomeProj.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Informe o Nome do Projeto.");
            return;
        }
        if (cbTipoProjeto.getSelectedIndex() == 0) {
            JOptionPane.showMessageDialog(this, "Selecione o Tipo do Projeto.");
            return;
        }
        if (cbStatus.getSelectedIndex() == 0) {
            JOptionPane.showMessageDialog(this, "Selecione o Status do Projeto.");
            return;
        }

        ProjetoOffshore p = new ProjetoOffshore();

        if (modoEdicao) {
            p.setIdProjeto(Integer.parseInt(txtId.getText()));
        }

        // Ativo
        AtivoOffshore ativo = listaAtivos.get(idxAtivo - 1);
        p.setIdAtivo(ativo.getIdAtivo());

        // Responsável
        Funcionario func = listaFuncionarios.get(idxResp - 1);
        p.setIdResponsavel(func.getIdFuncionario());

        p.setNomeProjeto(nomeProj);
        p.setTipoProjeto(cbTipoProjeto.getSelectedItem().toString());
        p.setStatus(cbStatus.getSelectedItem().toString());
        p.setDescricao(txtDescricao.getText().trim());

        // Datas
        String dIniStr = txtDataInicio.getText().trim();
        String dFimStr = txtDataFimPrevista.getText().trim();
        try {
            if (!dIniStr.isEmpty()) {
                p.setDataInicio(Date.valueOf(dIniStr));
            } else {
                p.setDataInicio(null);
            }
            if (!dFimStr.isEmpty()) {
                p.setDataFimPrevista(Date.valueOf(dFimStr));
            } else {
                p.setDataFimPrevista(null);
            }
        } catch (IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(this,
                    "Data em formato inválido. Use AAAA-MM-DD.",
                    "Data inválida",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        try {
            if (modoEdicao) {
                projetoDAO.atualizar(p);
                JOptionPane.showMessageDialog(this, "Projeto atualizado com sucesso.");
            } else {
                projetoDAO.inserir(p);
                JOptionPane.showMessageDialog(this, "Projeto inserido com sucesso.");
            }
            carregarProjetos();
            cancelar();
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this,
                    "Erro ao salvar projeto: " + ex.getMessage(),
                    "Erro",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    private void excluir() {
        if (txtId.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Selecione um projeto para excluir.");
            return;
        }
        int op = JOptionPane.showConfirmDialog(this,
                "Deseja realmente excluir este projeto?",
                "Excluir",
                JOptionPane.YES_NO_OPTION);

        if (op == JOptionPane.YES_OPTION) {
            try {
                int id = Integer.parseInt(txtId.getText());
                projetoDAO.deletar(id);
                JOptionPane.showMessageDialog(this, "Projeto excluído com sucesso.");
                carregarProjetos();
                limparCampos();
            } catch (Exception ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(this,
                        "Erro ao excluir projeto: " + ex.getMessage(),
                        "Erro",
                        JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void cancelar() {
        limparCampos();
        habilitarCampos(false);
        btnSalvar.setEnabled(false);
        btnCancelar.setEnabled(false);
        modoEdicao = false;
    }

    // ================= CARREGAR LISTAS ===================

    private void carregarAtivos() {
        cbAtivo.removeAllItems();
        listaAtivos.clear();
        cbAtivo.addItem("Selecione...");

        try {
            listaAtivos = ativoDAO.listarTodos();
            for (AtivoOffshore a : listaAtivos) {
                cbAtivo.addItem(a.getIdAtivo() + " - " + a.getNomeAtivo());
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this,
                    "Erro ao carregar ativos: " + ex.getMessage(),
                    "Erro",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    private void carregarFuncionarios() {
        cbResponsavel.removeAllItems();
        listaFuncionarios.clear();
        cbResponsavel.addItem("Selecione...");

        try {
            List<Funcionario> lista = funcionarioDAO.listarTodos();
            for (Funcionario f : lista) {
                // Se quiser filtrar só ativos:
                if (f.isAtivo()) {
                    listaFuncionarios.add(f);
                    cbResponsavel.addItem(f.getIdFuncionario() + " - " + f.getNome());
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this,
                    "Erro ao carregar funcionários: " + ex.getMessage(),
                    "Erro",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    private void carregarProjetos() {
        modelo.setRowCount(0);
        listaProjetos.clear();

        try {
            listaProjetos = projetoDAO.listarTodos();
            for (ProjetoOffshore p : listaProjetos) {
                String nomeAtivo = buscarNomeAtivo(p.getIdAtivo());
                String nomeResp = buscarNomeResponsavel(p.getIdResponsavel());

                modelo.addRow(new Object[]{
                        p.getIdProjeto(),
                        nomeAtivo,
                        nomeResp,
                        p.getNomeProjeto(),
                        p.getTipoProjeto(),
                        p.getStatus(),
                        p.getDataInicio() != null ? p.getDataInicio().toString() : "",
                        p.getDataFimPrevista() != null ? p.getDataFimPrevista().toString() : ""
                });
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this,
                    "Erro ao carregar projetos: " + ex.getMessage(),
                    "Erro",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    private String buscarNomeAtivo(int idAtivo) {
        for (AtivoOffshore a : listaAtivos) {
            if (a.getIdAtivo() == idAtivo) {
                return a.getNomeAtivo();
            }
        }
        return "-";
    }

    private String buscarNomeResponsavel(int idResp) {
        for (Funcionario f : listaFuncionarios) {
            if (f.getIdFuncionario() == idResp) {
                return f.getNome();
            }
        }
        return "-";
    }

    private void carregarDaTabela(int linha) {
        if (linha < 0 || linha >= listaProjetos.size()) return;

        ProjetoOffshore p = listaProjetos.get(linha);

        txtId.setText(String.valueOf(p.getIdProjeto()));
        txtNomeProjeto.setText(p.getNomeProjeto());
        cbTipoProjeto.setSelectedItem(p.getTipoProjeto());
        cbStatus.setSelectedItem(p.getStatus());
        txtDataInicio.setText(p.getDataInicio() != null ? p.getDataInicio().toString() : "");
        txtDataFimPrevista.setText(p.getDataFimPrevista() != null ? p.getDataFimPrevista().toString() : "");
        txtDescricao.setText(p.getDescricao() != null ? p.getDescricao() : "");

        // Selecionar Ativo
        int idxAtivoCombo = 0;
        for (int i = 0; i < listaAtivos.size(); i++) {
            if (listaAtivos.get(i).getIdAtivo() == p.getIdAtivo()) {
                idxAtivoCombo = i + 1; // +1 por causa do "Selecione..."
                break;
            }
        }
        cbAtivo.setSelectedIndex(idxAtivoCombo);

        // Selecionar Responsável
        int idxRespCombo = 0;
        for (int i = 0; i < listaFuncionarios.size(); i++) {
            if (listaFuncionarios.get(i).getIdFuncionario() == p.getIdResponsavel()) {
                idxRespCombo = i + 1; // +1 por causa do "Selecione..."
                break;
            }
        }
        cbResponsavel.setSelectedIndex(idxRespCombo);

        habilitarCampos(false);
        btnSalvar.setEnabled(false);
        btnCancelar.setEnabled(false);
        modoEdicao = false;
    }
}


