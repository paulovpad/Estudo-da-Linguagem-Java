package sisoff.view;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;

public class TelaPrincipal extends JFrame {

    private BackgroundDesktopPane desktop;
    private JLabel lblStatus;

    public TelaPrincipal() {
        inicializarComponentes();
    }

    private void inicializarComponentes() {
        setTitle("SISOFF - Sistema de Gestão de Projetos e Documentos Offshore");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1000, 700);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // Desktop com imagem de fundo
        desktop = new BackgroundDesktopPane("/sisoff/imagens/oil.jpg");

        // Overlay com texto "Bem-vindo ao SISOFF"
        JPanel overlay = new JPanel(new GridBagLayout());
        overlay.setOpaque(false);

        JLabel lblBemVindo = new JLabel(
                "<html><center>" +
                        "<span style='font-size:26px; font-weight:bold; color:#FFFFFF; text-decoration:underline;'>"
                        + "Bem-vindo ao SISOFF</span><br>" +
                        "<span style='font-size:14px; color:#FFFFFF;'>"
                        + "Sistema de Gestão de Projetos, Etapas e Documentos Offshore</span>" +
                        "</center></html>"
        );
        lblBemVindo.setHorizontalAlignment(SwingConstants.CENTER);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        overlay.add(lblBemVindo, gbc);

        desktop.setLayout(new BorderLayout());
        desktop.add(overlay, BorderLayout.CENTER);

        add(desktop, BorderLayout.CENTER);

        // Barra de status
        lblStatus = new JLabel("  Pronto.");
        lblStatus.setBorder(BorderFactory.createEmptyBorder(3, 5, 3, 5));
        add(lblStatus, BorderLayout.SOUTH);

        // Menu
        setJMenuBar(criarMenuBar());
    }

    private JMenuBar criarMenuBar() {
        JMenuBar menuBar = new JMenuBar();

        // ==== MENU CADASTROS ====
        JMenu menuCadastros = new JMenu("Cadastros");
        menuCadastros.setMnemonic(KeyEvent.VK_C);

        JMenuItem miFuncionarios = new JMenuItem("Funcionários");
        miFuncionarios.addActionListener((ActionEvent e) -> abrirCadastroFuncionarios());

        JMenuItem miAtivos = new JMenuItem("Ativos Offshore");
        miAtivos.addActionListener((ActionEvent e) -> abrirCadastroAtivos());

        menuCadastros.add(miFuncionarios);
        menuCadastros.add(miAtivos);

        // ==== MENU PROJETOS ====
        JMenu menuProjetos = new JMenu("Projetos");
        menuProjetos.setMnemonic(KeyEvent.VK_P);

        JMenuItem miProjetosOffshore = new JMenuItem("Projetos Offshore");
        miProjetosOffshore.addActionListener((ActionEvent e) -> abrirCadastroProjetos());

        JMenuItem miEtapasProjeto = new JMenuItem("Etapas de Projeto");
        miEtapasProjeto.addActionListener((ActionEvent e) -> abrirCadastroEtapas());

        menuProjetos.add(miProjetosOffshore);
        menuProjetos.add(miEtapasProjeto);

        // ==== MENU DOCUMENTOS ====
        JMenu menuDocumentos = new JMenu("Documentos");
        menuDocumentos.setMnemonic(KeyEvent.VK_D);

        JMenuItem miDocsProjeto = new JMenuItem("Documentos de Projeto");
        miDocsProjeto.addActionListener((ActionEvent e) -> abrirCadastroDocumentos());

        menuDocumentos.add(miDocsProjeto);

        // ==== MENU RELATÓRIOS ====
        JMenu menuRelatorios = new JMenu("Relatórios");
        menuRelatorios.setMnemonic(KeyEvent.VK_R);

        JMenuItem miProjStatus = new JMenuItem("Projetos por Status");
        miProjStatus.addActionListener((ActionEvent e) -> abrirRelatorioProjetosStatus());

        JMenuItem miEtapasPendentes = new JMenuItem("Etapas por Status");
        miEtapasPendentes.addActionListener((ActionEvent e) -> abrirRelatorioEtapasPendentes());

        JMenuItem miDocsPorProjeto = new JMenuItem("Documentos por Projeto");
        miDocsPorProjeto.addActionListener((ActionEvent e) -> abrirRelatorioDocumentosProjeto());

        menuRelatorios.add(miProjStatus);
        menuRelatorios.add(miEtapasPendentes);
        menuRelatorios.add(miDocsPorProjeto);

        // ==== MENU SISTEMA ====
        JMenu menuSistema = new JMenu("Sistema");
        menuSistema.setMnemonic(KeyEvent.VK_S);

        JMenuItem miSobre = new JMenuItem("Sobre");
        miSobre.addActionListener((ActionEvent e) -> {
            lblStatus.setText("  Sobre o sistema.");
            JOptionPane.showMessageDialog(this,
                    "SISOFF - Sistema de Gestão de Projetos e Documentos Offshore\n"
                            + "Projeto final em Java com MySQL.\n\n"
                            + "Funcionalidades principais:\n"
                            + " - Cadastro de Funcionários e Ativos Offshore\n"
                            + " - Gestão de Projetos, Etapas e Documentos\n"
                            + " - Relatórios de apoio ao planejamento e controle",
                    "Sobre o SISOFF",
                    JOptionPane.INFORMATION_MESSAGE);
        });

        JMenuItem miSair = new JMenuItem("Sair");
        miSair.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_Q, KeyEvent.CTRL_DOWN_MASK));
        miSair.addActionListener((ActionEvent e) -> {
            int opc = JOptionPane.showConfirmDialog(this,
                    "Deseja realmente sair do sistema?",
                    "Sair",
                    JOptionPane.YES_NO_OPTION);
            if (opc == JOptionPane.YES_OPTION) {
                System.exit(0);
            }
        });

        menuSistema.add(miSobre);
        menuSistema.addSeparator();
        menuSistema.add(miSair);

        // ==== ADICIONA MENUS NA BARRA ====
        menuBar.add(menuCadastros);
        menuBar.add(menuProjetos);
        menuBar.add(menuDocumentos);
        menuBar.add(menuRelatorios);
        menuBar.add(menuSistema);

        return menuBar;
    }

    // ==== ABRIR TELAS ====

    private void abrirCadastroFuncionarios() {
        CadastroFuncionarioFrame frame = new CadastroFuncionarioFrame();
        desktop.add(frame);
        frame.setVisible(true);
        try { frame.setSelected(true); } catch (Exception ignored) {}
        lblStatus.setText("  Cadastro de Funcionários.");
    }

    private void abrirCadastroAtivos() {
        CadastroAtivoOffshoreFrame frame = new CadastroAtivoOffshoreFrame();
        desktop.add(frame);
        frame.setVisible(true);
        try { frame.setSelected(true); } catch (Exception ignored) {}
        lblStatus.setText("  Cadastro de Ativos Offshore.");
    }

    private void abrirCadastroProjetos() {
        CadastroProjetoOffshoreFrame frame = new CadastroProjetoOffshoreFrame();
        desktop.add(frame);
        frame.setVisible(true);
        try { frame.setSelected(true); } catch (Exception ignored) {}
        lblStatus.setText("  Cadastro de Projetos Offshore.");
    }

    private void abrirCadastroEtapas() {
        CadastroEtapaProjetoFrame frame = new CadastroEtapaProjetoFrame();
        desktop.add(frame);
        frame.setVisible(true);
        try { frame.setSelected(true); } catch (Exception ignored) {}
        lblStatus.setText("  Cadastro de Etapas de Projeto.");
    }

    private void abrirCadastroDocumentos() {
        CadastroDocumentoProjetoFrame frame = new CadastroDocumentoProjetoFrame();
        desktop.add(frame);
        frame.setVisible(true);
        try { frame.setSelected(true); } catch (Exception ignored) {}
        lblStatus.setText("  Documentos de Projeto.");
    }

    private void abrirRelatorioProjetosStatus() {
        RelatorioProjetosStatusFrame frame = new RelatorioProjetosStatusFrame();
        desktop.add(frame);
        frame.setVisible(true);
        try { frame.setSelected(true); } catch (Exception ignored) {}
        lblStatus.setText("  Relatório: Projetos por Status.");
    }

    private void abrirRelatorioEtapasPendentes() {
        RelatorioEtapasPendentesFrame frame = new RelatorioEtapasPendentesFrame();
        desktop.add(frame);
        frame.setVisible(true);
        try { frame.setSelected(true); } catch (Exception ignored) {}
        lblStatus.setText("  Relatório: Etapas por Status.");
    }

    private void abrirRelatorioDocumentosProjeto() {
        RelatorioDocumentosProjetoFrame frame = new RelatorioDocumentosProjetoFrame();
        desktop.add(frame);
        frame.setVisible(true);
        try { frame.setSelected(true); } catch (Exception ignored) {}
        lblStatus.setText("  Relatório: Documentos por Projeto.");
    }

    // ==== Desktop com imagem de fundo ====

    private static class BackgroundDesktopPane extends JDesktopPane {
        private Image backgroundImage;

        public BackgroundDesktopPane(String resourcePath) {
            try {
                ImageIcon icon = new ImageIcon(getClass().getResource(resourcePath));
                backgroundImage = icon.getImage();
            } catch (Exception e) {
                backgroundImage = null;
            }
            setOpaque(false);
        }

        @Override
        protected void paintComponent(Graphics g) {
            if (backgroundImage != null) {
                g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
            } else {
                g.setColor(new Color(230, 233, 237));
                g.fillRect(0, 0, getWidth(), getHeight());
            }
            super.paintComponent(g);
        }
    }

    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ignored) {}

        SwingUtilities.invokeLater(() -> {
            TelaPrincipal tela = new TelaPrincipal();
            tela.setVisible(true);
        });
    }
}

