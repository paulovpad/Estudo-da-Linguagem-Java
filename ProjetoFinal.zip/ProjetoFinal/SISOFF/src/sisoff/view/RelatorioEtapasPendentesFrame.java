package sisoff.view;

import sisoff.dao.EtapaProjetoDAO;
import sisoff.dao.ProjetoOffshoreDAO;
import sisoff.model.EtapaProjeto;
import sisoff.model.ProjetoOffshore;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class RelatorioEtapasPendentesFrame extends JInternalFrame {

    private JComboBox<String> cbStatus;
    private JButton btnFiltrar;
    private JButton btnLimpar;
    private JTable tabela;
    private DefaultTableModel modelo;

    private EtapaProjetoDAO etapaDAO;
    private ProjetoOffshoreDAO projetoDAO;

    private List<EtapaProjeto> listaEtapas = new ArrayList<>();
    private List<ProjetoOffshore> listaProjetos = new ArrayList<>();

    public RelatorioEtapasPendentesFrame() {
        super("Relatório - Etapas por Status", true, true, true, true);

        etapaDAO = new EtapaProjetoDAO();
        projetoDAO = new ProjetoOffshoreDAO();

        inicializarComponentes();
        carregarProjetos();
        carregarEtapas();   // carrega todas inicialmente
    }

    private void inicializarComponentes() {
        setSize(950, 550);
        setLayout(new BorderLayout(10, 10));

        // Painel de filtro
        JPanel painelFiltro = new JPanel(new FlowLayout(FlowLayout.LEFT));
        painelFiltro.setBorder(BorderFactory.createTitledBorder("Filtro"));

        JLabel lblStatus = new JLabel("Status da Etapa:");

        cbStatus = new JComboBox<>(new String[]{
                "Todos",
                "Pendente",
                "Em andamento",
                "Aguardando recursos",
                "Concluída",
                "Cancelada"
        });

        btnFiltrar = new JButton("Filtrar");
        btnLimpar = new JButton("Limpar");

        painelFiltro.add(lblStatus);
        painelFiltro.add(cbStatus);
        painelFiltro.add(btnFiltrar);
        painelFiltro.add(btnLimpar);

        // Tabela
        modelo = new DefaultTableModel(
                new Object[]{
                        "ID Etapa",
                        "Projeto",
                        "Nome da Etapa",
                        "Responsável",
                        "Prev. Início",
                        "Prev. Fim",
                        "Conclusão",
                        "Status"
                }, 0
        ) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        tabela = new JTable(modelo);
        JScrollPane scrollTabela = new JScrollPane(tabela);
        scrollTabela.setBorder(BorderFactory.createTitledBorder("Etapas"));

        add(painelFiltro, BorderLayout.NORTH);
        add(scrollTabela, BorderLayout.CENTER);

        // Eventos
        btnFiltrar.addActionListener(e -> aplicarFiltro());
        btnLimpar.addActionListener(e -> limparFiltro());
    }

    private void carregarProjetos() {
        try {
            listaProjetos = projetoDAO.listarTodos();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                    "Erro ao carregar projetos: " + e.getMessage(),
                    "Erro",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    private void carregarEtapas() {
        modelo.setRowCount(0);
        listaEtapas.clear();

        try {
            listaEtapas = etapaDAO.listarTodas();

            for (EtapaProjeto et : listaEtapas) {
                String nomeProjeto = buscarNomeProjeto(et.getIdProjeto());

                modelo.addRow(new Object[]{
                        et.getIdEtapa(),
                        nomeProjeto,
                        et.getNomeEtapa(),
                        et.getResponsavelEtapa() != null ? et.getResponsavelEtapa() : "",
                        et.getDataPrevistaInicio() != null ? et.getDataPrevistaInicio().toString() : "",
                        et.getDataPrevistaFim() != null ? et.getDataPrevistaFim().toString() : "",
                        et.getDataConclusao() != null ? et.getDataConclusao().toString() : "",
                        et.getStatusEtapa()
                });
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                    "Erro ao carregar etapas: " + e.getMessage(),
                    "Erro",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    private void aplicarFiltro() {
        String statusFiltro = cbStatus.getSelectedItem().toString();

        modelo.setRowCount(0); // limpa tabela

        for (EtapaProjeto et : listaEtapas) {

            // Se não for "Todos", filtra pelo status
            if (!statusFiltro.equals("Todos")
                    && !et.getStatusEtapa().equalsIgnoreCase(statusFiltro)) {
                continue;
            }

            String nomeProjeto = buscarNomeProjeto(et.getIdProjeto());

            modelo.addRow(new Object[]{
                    et.getIdEtapa(),
                    nomeProjeto,
                    et.getNomeEtapa(),
                    et.getResponsavelEtapa() != null ? et.getResponsavelEtapa() : "",
                    et.getDataPrevistaInicio() != null ? et.getDataPrevistaInicio().toString() : "",
                    et.getDataPrevistaFim() != null ? et.getDataPrevistaFim().toString() : "",
                    et.getDataConclusao() != null ? et.getDataConclusao().toString() : "",
                    et.getStatusEtapa()
            });
        }
    }

    private void limparFiltro() {
        cbStatus.setSelectedIndex(0); // "Todos"
        carregarEtapas();
    }

    private String buscarNomeProjeto(int idProjeto) {
        for (ProjetoOffshore p : listaProjetos) {
            if (p.getIdProjeto() == idProjeto) {
                return p.getNomeProjeto();
            }
        }
        return "-";
    }
}

