package sisoff.dao;

import sisoff.model.AtivoOffshore;
import sisoff.util.ConnectionFactory;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class AtivoOffshoreDAO {

    // INSERT
    public void inserir(AtivoOffshore a) {
        String sql = "INSERT INTO ativo_offshore "
                   + "(nome_ativo, tipo_ativo, localizacao, operador) "
                   + "VALUES (?, ?, ?, ?)";

        Connection conn = null;
        PreparedStatement stmt = null;

        try {
            conn = ConnectionFactory.getConnection();
            stmt = conn.prepareStatement(sql);

            stmt.setString(1, a.getNomeAtivo());
            stmt.setString(2, a.getTipoAtivo());
            stmt.setString(3, a.getLocalizacao());
            stmt.setString(4, a.getOperador());

            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao inserir ativo offshore: " + e.getMessage(), e);
        } finally {
            ConnectionFactory.closeConnection(conn, stmt);
        }
    }

    // UPDATE
    public void atualizar(AtivoOffshore a) {
        String sql = "UPDATE ativo_offshore SET "
                   + "nome_ativo = ?, tipo_ativo = ?, localizacao = ?, operador = ? "
                   + "WHERE id_ativo = ?";

        Connection conn = null;
        PreparedStatement stmt = null;

        try {
            conn = ConnectionFactory.getConnection();
            stmt = conn.prepareStatement(sql);

            stmt.setString(1, a.getNomeAtivo());
            stmt.setString(2, a.getTipoAtivo());
            stmt.setString(3, a.getLocalizacao());
            stmt.setString(4, a.getOperador());
            stmt.setInt(5, a.getIdAtivo());

            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao atualizar ativo offshore: " + e.getMessage(), e);
        } finally {
            ConnectionFactory.closeConnection(conn, stmt);
        }
    }

    // DELETE
    public void deletar(int idAtivo) {
        String sql = "DELETE FROM ativo_offshore WHERE id_ativo = ?";

        Connection conn = null;
        PreparedStatement stmt = null;

        try {
            conn = ConnectionFactory.getConnection();
            stmt = conn.prepareStatement(sql);
            stmt.setInt(1, idAtivo);
            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao deletar ativo offshore: " + e.getMessage(), e);
        } finally {
            ConnectionFactory.closeConnection(conn, stmt);
        }
    }

    // LISTAR TODOS
    public List<AtivoOffshore> listarTodos() {
        String sql = "SELECT * FROM ativo_offshore";

        List<AtivoOffshore> lista = new ArrayList<>();
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            conn = ConnectionFactory.getConnection();
            stmt = conn.prepareStatement(sql);
            rs = stmt.executeQuery();

            while (rs.next()) {
                AtivoOffshore a = new AtivoOffshore();
                a.setIdAtivo(rs.getInt("id_ativo"));
                a.setNomeAtivo(rs.getString("nome_ativo"));
                a.setTipoAtivo(rs.getString("tipo_ativo"));
                a.setLocalizacao(rs.getString("localizacao"));
                a.setOperador(rs.getString("operador"));

                lista.add(a);
            }
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao listar ativos offshore: " + e.getMessage(), e);
        } finally {
            ConnectionFactory.closeConnection(conn, stmt, rs);
        }

        return lista;
    }

    // BUSCAR POR ID
    public AtivoOffshore buscarPorId(int idAtivo) {
        String sql = "SELECT * FROM ativo_offshore WHERE id_ativo = ?";

        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        AtivoOffshore a = null;

        try {
            conn = ConnectionFactory.getConnection();
            stmt = conn.prepareStatement(sql);
            stmt.setInt(1, idAtivo);
            rs = stmt.executeQuery();

            if (rs.next()) {
                a = new AtivoOffshore();
                a.setIdAtivo(rs.getInt("id_ativo"));
                a.setNomeAtivo(rs.getString("nome_ativo"));
                a.setTipoAtivo(rs.getString("tipo_ativo"));
                a.setLocalizacao(rs.getString("localizacao"));
                a.setOperador(rs.getString("operador"));
            }
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao buscar ativo offshore por ID: " + e.getMessage(), e);
        } finally {
            ConnectionFactory.closeConnection(conn, stmt, rs);
        }

        return a;
    }
}

