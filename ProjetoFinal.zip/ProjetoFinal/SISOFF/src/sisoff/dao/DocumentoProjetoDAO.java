package sisoff.dao;

import sisoff.model.DocumentoProjeto;
import sisoff.util.ConnectionFactory;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DocumentoProjetoDAO {

    public void inserir(DocumentoProjeto d) {
        String sql = "INSERT INTO documento_projeto (" +
                "id_projeto, id_etapa, titulo, tipo_documento, data_emissao, " +
                "responsavel_elaboracao, observacao) VALUES (?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = ConnectionFactory.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, d.getIdProjeto());

            if (d.getIdEtapa() != null) {
                stmt.setInt(2, d.getIdEtapa());
            } else {
                stmt.setNull(2, Types.INTEGER);
            }

            stmt.setString(3, d.getTitulo());
            stmt.setString(4, d.getTipoDocumento());
            stmt.setDate(5, d.getDataEmissao());
            stmt.setString(6, d.getResponsavelElaboracao());
            stmt.setString(7, d.getObservacao());

            stmt.executeUpdate();

        } catch (SQLException e) {
            throw new RuntimeException("Erro ao inserir documento: " + e.getMessage(), e);
        }
    }

    public void atualizar(DocumentoProjeto d) {
        String sql = "UPDATE documento_projeto SET " +
                "id_projeto=?, id_etapa=?, titulo=?, tipo_documento=?, data_emissao=?, " +
                "responsavel_elaboracao=?, observacao=? WHERE id_documento=?";

        try (Connection conn = ConnectionFactory.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, d.getIdProjeto());

            if (d.getIdEtapa() != null) {
                stmt.setInt(2, d.getIdEtapa());
            } else {
                stmt.setNull(2, Types.INTEGER);
            }

            stmt.setString(3, d.getTitulo());
            stmt.setString(4, d.getTipoDocumento());
            stmt.setDate(5, d.getDataEmissao());
            stmt.setString(6, d.getResponsavelElaboracao());
            stmt.setString(7, d.getObservacao());

            stmt.setInt(8, d.getIdDocumento());

            stmt.executeUpdate();

        } catch (SQLException e) {
            throw new RuntimeException("Erro ao atualizar documento: " + e.getMessage(), e);
        }
    }

    public void deletar(int id) {
        String sql = "DELETE FROM documento_projeto WHERE id_documento=?";

        try (Connection conn = ConnectionFactory.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, id);
            stmt.executeUpdate();

        } catch (SQLException e) {
            throw new RuntimeException("Erro ao excluir documento: " + e.getMessage(), e);
        }
    }

    public DocumentoProjeto buscarPorId(int id) {
        String sql = "SELECT * FROM documento_projeto WHERE id_documento=?";

        try (Connection conn = ConnectionFactory.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                DocumentoProjeto d = new DocumentoProjeto();
                d.setIdDocumento(rs.getInt("id_documento"));
                d.setIdProjeto(rs.getInt("id_projeto"));

                int idEtapa = rs.getInt("id_etapa");
                d.setIdEtapa(rs.wasNull() ? null : idEtapa);

                d.setTitulo(rs.getString("titulo"));
                d.setTipoDocumento(rs.getString("tipo_documento"));
                d.setDataEmissao(rs.getDate("data_emissao"));
                d.setResponsavelElaboracao(rs.getString("responsavel_elaboracao"));
                d.setObservacao(rs.getString("observacao"));

                return d;
            }
            return null;

        } catch (SQLException e) {
            throw new RuntimeException("Erro ao buscar documento: " + e.getMessage(), e);
        }
    }

    public List<DocumentoProjeto> listarTodos() {
        String sql = "SELECT * FROM documento_projeto ORDER BY id_documento DESC";
        List<DocumentoProjeto> lista = new ArrayList<>();

        try (Connection conn = ConnectionFactory.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                DocumentoProjeto d = new DocumentoProjeto();

                d.setIdDocumento(rs.getInt("id_documento"));
                d.setIdProjeto(rs.getInt("id_projeto"));

                int idEtapa = rs.getInt("id_etapa");
                d.setIdEtapa(rs.wasNull() ? null : idEtapa);

                d.setTitulo(rs.getString("titulo"));
                d.setTipoDocumento(rs.getString("tipo_documento"));
                d.setDataEmissao(rs.getDate("data_emissao"));
                d.setResponsavelElaboracao(rs.getString("responsavel_elaboracao"));
                d.setObservacao(rs.getString("observacao"));

                lista.add(d);
            }

        } catch (SQLException e) {
            throw new RuntimeException("Erro ao listar documentos: " + e.getMessage(), e);
        }

        return lista;
    }
}

