package sisoff.dao;

import sisoff.model.Funcionario;
import sisoff.util.ConnectionFactory;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class FuncionarioDAO {

    // INSERT
    public void inserir(Funcionario f) {
        String sql = "INSERT INTO funcionario "
                   + "(nome, usuario, senha, cargo, ativo) "
                   + "VALUES (?, ?, ?, ?, ?)";

        Connection conn = null;
        PreparedStatement stmt = null;

        try {
            conn = ConnectionFactory.getConnection();
            stmt = conn.prepareStatement(sql);

            stmt.setString(1, f.getNome());
            stmt.setString(2, f.getUsuario());
            stmt.setString(3, f.getSenha());
            stmt.setString(4, f.getCargo());
            stmt.setBoolean(5, f.isAtivo());

            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao inserir funcionário: " + e.getMessage(), e);
        } finally {
            ConnectionFactory.closeConnection(conn, stmt);
        }
    }

    // UPDATE
    public void atualizar(Funcionario f) {
        String sql = "UPDATE funcionario SET "
                   + "nome = ?, usuario = ?, senha = ?, cargo = ?, ativo = ? "
                   + "WHERE id_funcionario = ?";

        Connection conn = null;
        PreparedStatement stmt = null;

        try {
            conn = ConnectionFactory.getConnection();
            stmt = conn.prepareStatement(sql);

            stmt.setString(1, f.getNome());
            stmt.setString(2, f.getUsuario());
            stmt.setString(3, f.getSenha());
            stmt.setString(4, f.getCargo());
            stmt.setBoolean(5, f.isAtivo());
            stmt.setInt(6, f.getIdFuncionario());

            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao atualizar funcionário: " + e.getMessage(), e);
        } finally {
            ConnectionFactory.closeConnection(conn, stmt);
        }
    }

    // DELETE
    public void deletar(int idFuncionario) {
        String sql = "DELETE FROM funcionario WHERE id_funcionario = ?";

        Connection conn = null;
        PreparedStatement stmt = null;

        try {
            conn = ConnectionFactory.getConnection();
            stmt = conn.prepareStatement(sql);
            stmt.setInt(1, idFuncionario);
            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao deletar funcionário: " + e.getMessage(), e);
        } finally {
            ConnectionFactory.closeConnection(conn, stmt);
        }
    }

    // LISTAR TODOS
    public List<Funcionario> listarTodos() {
        String sql = "SELECT * FROM funcionario";

        List<Funcionario> lista = new ArrayList<>();
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            conn = ConnectionFactory.getConnection();
            stmt = conn.prepareStatement(sql);
            rs = stmt.executeQuery();

            while (rs.next()) {
                Funcionario f = new Funcionario();
                f.setIdFuncionario(rs.getInt("id_funcionario"));
                f.setNome(rs.getString("nome"));
                f.setUsuario(rs.getString("usuario"));
                f.setSenha(rs.getString("senha"));
                f.setCargo(rs.getString("cargo"));
                f.setAtivo(rs.getBoolean("ativo"));

                lista.add(f);
            }
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao listar funcionários: " + e.getMessage(), e);
        } finally {
            ConnectionFactory.closeConnection(conn, stmt, rs);
        }

        return lista;
    }

    // BUSCAR POR ID
    public Funcionario buscarPorId(int idFuncionario) {
        String sql = "SELECT * FROM funcionario WHERE id_funcionario = ?";

        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        Funcionario f = null;

        try {
            conn = ConnectionFactory.getConnection();
            stmt = conn.prepareStatement(sql);
            stmt.setInt(1, idFuncionario);
            rs = stmt.executeQuery();

            if (rs.next()) {
                f = new Funcionario();
                f.setIdFuncionario(rs.getInt("id_funcionario"));
                f.setNome(rs.getString("nome"));
                f.setUsuario(rs.getString("usuario"));
                f.setSenha(rs.getString("senha"));
                f.setCargo(rs.getString("cargo"));
                f.setAtivo(rs.getBoolean("ativo"));
            }
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao buscar funcionário por ID: " + e.getMessage(), e);
        } finally {
            ConnectionFactory.closeConnection(conn, stmt, rs);
        }

        return f;
    }

    // LOGIN: BUSCAR POR USUÁRIO E SENHA
    public Funcionario buscarPorUsuarioESenha(String usuario, String senha) {
        String sql = "SELECT * FROM funcionario "
                   + "WHERE usuario = ? AND senha = ? AND ativo = 1";

        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        Funcionario f = null;

        try {
            conn = ConnectionFactory.getConnection();
            stmt = conn.prepareStatement(sql);
            stmt.setString(1, usuario);
            stmt.setString(2, senha);
            rs = stmt.executeQuery();

            if (rs.next()) {
                f = new Funcionario();
                f.setIdFuncionario(rs.getInt("id_funcionario"));
                f.setNome(rs.getString("nome"));
                f.setUsuario(rs.getString("usuario"));
                f.setSenha(rs.getString("senha"));
                f.setCargo(rs.getString("cargo"));
                f.setAtivo(rs.getBoolean("ativo"));
            }
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao autenticar funcionário: " + e.getMessage(), e);
        } finally {
            ConnectionFactory.closeConnection(conn, stmt, rs);
        }

        return f;
    }
}

