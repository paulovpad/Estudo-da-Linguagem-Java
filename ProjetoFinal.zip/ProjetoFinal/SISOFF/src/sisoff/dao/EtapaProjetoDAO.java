package sisoff.dao;

import sisoff.model.EtapaProjeto;
import sisoff.util.ConnectionFactory;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class EtapaProjetoDAO {

    public void inserir(EtapaProjeto e) {
        String sql = "INSERT INTO etapa_projeto (" +
                "id_projeto, nome_etapa, responsavel_etapa, " +
                "data_prevista_inicio, data_prevista_fim, data_conclusao, " +
                "status_etapa, observacao) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = ConnectionFactory.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, e.getIdProjeto());
            stmt.setString(2, e.getNomeEtapa());
            stmt.setString(3, e.getResponsavelEtapa());

            stmt.setDate(4, e.getDataPrevistaInicio());
            stmt.setDate(5, e.getDataPrevistaFim());
            stmt.setDate(6, e.getDataConclusao());

            stmt.setString(7, e.getStatusEtapa());
            stmt.setString(8, e.getObservacao());

            stmt.executeUpdate();

        } catch (SQLException ex) {
            throw new RuntimeException("Erro ao inserir etapa: " + ex.getMessage(), ex);
        }
    }

    public void atualizar(EtapaProjeto e) {
        String sql = "UPDATE etapa_projeto SET " +
                "id_projeto=?, nome_etapa=?, responsavel_etapa=?, " +
                "data_prevista_inicio=?, data_prevista_fim=?, data_conclusao=?, " +
                "status_etapa=?, observacao=? " +
                "WHERE id_etapa=?";

        try (Connection conn = ConnectionFactory.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, e.getIdProjeto());
            stmt.setString(2, e.getNomeEtapa());
            stmt.setString(3, e.getResponsavelEtapa());
            stmt.setDate(4, e.getDataPrevistaInicio());
            stmt.setDate(5, e.getDataPrevistaFim());
            stmt.setDate(6, e.getDataConclusao());
            stmt.setString(7, e.getStatusEtapa());
            stmt.setString(8, e.getObservacao());
            stmt.setInt(9, e.getIdEtapa());

            stmt.executeUpdate();

        } catch (SQLException ex) {
            throw new RuntimeException("Erro ao atualizar etapa: " + ex.getMessage(), ex);
        }
    }

    public void deletar(int idEtapa) {
        String sql = "DELETE FROM etapa_projeto WHERE id_etapa=?";

        try (Connection conn = ConnectionFactory.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, idEtapa);
            stmt.executeUpdate();

        } catch (SQLException ex) {
            throw new RuntimeException("Erro ao excluir etapa: " + ex.getMessage(), ex);
        }
    }

    public EtapaProjeto buscarPorId(int idEtapa) {
        String sql = "SELECT * FROM etapa_projeto WHERE id_etapa=?";

        try (Connection conn = ConnectionFactory.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, idEtapa);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                EtapaProjeto e = new EtapaProjeto();
                e.setIdEtapa(rs.getInt("id_etapa"));
                e.setIdProjeto(rs.getInt("id_projeto"));
                e.setNomeEtapa(rs.getString("nome_etapa"));
                e.setResponsavelEtapa(rs.getString("responsavel_etapa"));
                e.setDataPrevistaInicio(rs.getDate("data_prevista_inicio"));
                e.setDataPrevistaFim(rs.getDate("data_prevista_fim"));
                e.setDataConclusao(rs.getDate("data_conclusao"));
                e.setStatusEtapa(rs.getString("status_etapa"));
                e.setObservacao(rs.getString("observacao"));
                return e;
            }
            return null;

        } catch (SQLException ex) {
            throw new RuntimeException("Erro ao buscar etapa: " + ex.getMessage(), ex);
        }
    }

    public List<EtapaProjeto> listarTodas() {
        String sql = "SELECT * FROM etapa_projeto ORDER BY id_etapa DESC";
        List<EtapaProjeto> lista = new ArrayList<>();

        try (Connection conn = ConnectionFactory.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                EtapaProjeto e = new EtapaProjeto();
                e.setIdEtapa(rs.getInt("id_etapa"));
                e.setIdProjeto(rs.getInt("id_projeto"));
                e.setNomeEtapa(rs.getString("nome_etapa"));
                e.setResponsavelEtapa(rs.getString("responsavel_etapa"));
                e.setDataPrevistaInicio(rs.getDate("data_prevista_inicio"));
                e.setDataPrevistaFim(rs.getDate("data_prevista_fim"));
                e.setDataConclusao(rs.getDate("data_conclusao"));
                e.setStatusEtapa(rs.getString("status_etapa"));
                e.setObservacao(rs.getString("observacao"));

                lista.add(e);
            }
            return lista;

        } catch (SQLException ex) {
            throw new RuntimeException("Erro ao listar etapas: " + ex.getMessage(), ex);
        }
    }
}
