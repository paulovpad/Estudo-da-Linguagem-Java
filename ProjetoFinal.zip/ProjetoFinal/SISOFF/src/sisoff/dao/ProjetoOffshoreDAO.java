package sisoff.dao;

import sisoff.model.ProjetoOffshore;
import sisoff.util.ConnectionFactory;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ProjetoOffshoreDAO {

    public void inserir(ProjetoOffshore p) {
        String sql = "INSERT INTO projeto_offshore (id_ativo, id_responsavel, nome_projeto, " +
                "tipo_projeto, data_inicio, data_fim_prevista, status, descricao) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = ConnectionFactory.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, p.getIdAtivo());
            stmt.setInt(2, p.getIdResponsavel());
            stmt.setString(3, p.getNomeProjeto());
            stmt.setString(4, p.getTipoProjeto());

            stmt.setDate(5, p.getDataInicio());
            stmt.setDate(6, p.getDataFimPrevista());

            stmt.setString(7, p.getStatus());
            stmt.setString(8, p.getDescricao());

            stmt.executeUpdate();

        } catch (SQLException e) {
            throw new RuntimeException("Erro ao inserir projeto: " + e.getMessage());
        }
    }

    public void atualizar(ProjetoOffshore p) {
        String sql = "UPDATE projeto_offshore SET id_ativo=?, id_responsavel=?, nome_projeto=?, " +
                "tipo_projeto=?, data_inicio=?, data_fim_prevista=?, status=?, descricao=? " +
                "WHERE id_projeto=?";

        try (Connection conn = ConnectionFactory.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, p.getIdAtivo());
            stmt.setInt(2, p.getIdResponsavel());
            stmt.setString(3, p.getNomeProjeto());
            stmt.setString(4, p.getTipoProjeto());
            stmt.setDate(5, p.getDataInicio());
            stmt.setDate(6, p.getDataFimPrevista());
            stmt.setString(7, p.getStatus());
            stmt.setString(8, p.getDescricao());
            stmt.setInt(9, p.getIdProjeto());

            stmt.executeUpdate();

        } catch (SQLException e) {
            throw new RuntimeException("Erro ao atualizar projeto: " + e.getMessage());
        }
    }

    public void deletar(int id) {
        String sql = "DELETE FROM projeto_offshore WHERE id_projeto=?";

        try (Connection conn = ConnectionFactory.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, id);
            stmt.executeUpdate();

        } catch (SQLException e) {
            throw new RuntimeException("Erro ao excluir projeto: " + e.getMessage());
        }
    }

    public ProjetoOffshore buscarPorId(int id) {
        String sql = "SELECT * FROM projeto_offshore WHERE id_projeto=?";

        try (Connection conn = ConnectionFactory.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                ProjetoOffshore p = new ProjetoOffshore();
                p.setIdProjeto(rs.getInt("id_projeto"));
                p.setIdAtivo(rs.getInt("id_ativo"));
                p.setIdResponsavel(rs.getInt("id_responsavel"));
                p.setNomeProjeto(rs.getString("nome_projeto"));
                p.setTipoProjeto(rs.getString("tipo_projeto"));
                p.setDataInicio(rs.getDate("data_inicio"));
                p.setDataFimPrevista(rs.getDate("data_fim_prevista"));
                p.setStatus(rs.getString("status"));
                p.setDescricao(rs.getString("descricao"));
                return p;
            }
            return null;

        } catch (SQLException e) {
            throw new RuntimeException("Erro ao buscar projeto: " + e.getMessage());
        }
    }

    public List<ProjetoOffshore> listarTodos() {
        String sql = "SELECT * FROM projeto_offshore ORDER BY id_projeto DESC";
        List<ProjetoOffshore> lista = new ArrayList<>();

        try (Connection conn = ConnectionFactory.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                ProjetoOffshore p = new ProjetoOffshore();
                p.setIdProjeto(rs.getInt("id_projeto"));
                p.setIdAtivo(rs.getInt("id_ativo"));
                p.setIdResponsavel(rs.getInt("id_responsavel"));
                p.setNomeProjeto(rs.getString("nome_projeto"));
                p.setTipoProjeto(rs.getString("tipo_projeto"));
                p.setDataInicio(rs.getDate("data_inicio"));
                p.setDataFimPrevista(rs.getDate("data_fim_prevista"));
                p.setStatus(rs.getString("status"));
                p.setDescricao(rs.getString("descricao"));

                lista.add(p);
            }
            return lista;

        } catch (SQLException e) {
            throw new RuntimeException("Erro ao listar projetos: " + e.getMessage());
        }
    }
}


