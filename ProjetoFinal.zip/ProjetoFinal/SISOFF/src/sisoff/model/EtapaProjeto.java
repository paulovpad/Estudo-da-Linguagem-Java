package sisoff.model;

import java.sql.Date;

public class EtapaProjeto {

    private int idEtapa;
    private int idProjeto;
    private String nomeEtapa;
    private String responsavelEtapa; // vamos guardar o NOME do funcionário
    private Date dataPrevistaInicio;
    private Date dataPrevistaFim;
    private Date dataConclusao;
    private String statusEtapa;
    private String observacao;

    public int getIdEtapa() {
        return idEtapa;
    }

    public void setIdEtapa(int idEtapa) {
        this.idEtapa = idEtapa;
    }

    public int getIdProjeto() {
        return idProjeto;
    }

    public void setIdProjeto(int idProjeto) {
        this.idProjeto = idProjeto;
    }

    public String getNomeEtapa() {
        return nomeEtapa;
    }

    public void setNomeEtapa(String nomeEtapa) {
        this.nomeEtapa = nomeEtapa;
    }

    public String getResponsavelEtapa() {
        return responsavelEtapa;
    }

    public void setResponsavelEtapa(String responsavelEtapa) {
        this.responsavelEtapa = responsavelEtapa;
    }

    public Date getDataPrevistaInicio() {
        return dataPrevistaInicio;
    }

    public void setDataPrevistaInicio(Date dataPrevistaInicio) {
        this.dataPrevistaInicio = dataPrevistaInicio;
    }

    public Date getDataPrevistaFim() {
        return dataPrevistaFim;
    }

    public void setDataPrevistaFim(Date dataPrevistaFim) {
        this.dataPrevistaFim = dataPrevistaFim;
    }

    public Date getDataConclusao() {
        return dataConclusao;
    }

    public void setDataConclusao(Date dataConclusao) {
        this.dataConclusao = dataConclusao;
    }

    public String getStatusEtapa() {
        return statusEtapa;
    }

    public void setStatusEtapa(String statusEtapa) {
        this.statusEtapa = statusEtapa;
    }

    public String getObservacao() {
        return observacao;
    }

    public void setObservacao(String observacao) {
        this.observacao = observacao;
    }
}


