package sisoff.model;

public class Funcionario {

    private int idFuncionario;
    private String nome;
    private String usuario;
    private String senha;
    private String cargo;
    private boolean ativo;

    public Funcionario() {
    }

    public Funcionario(int idFuncionario, String nome, String usuario, String senha, String cargo, boolean ativo) {
        this.idFuncionario = idFuncionario;
        this.nome = nome;
        this.usuario = usuario;
        this.senha = senha;
        this.cargo = cargo;
        this.ativo = ativo;
    }

    // Construtor sem id (útil para inserts)
    public Funcionario(String nome, String usuario, String senha, String cargo, boolean ativo) {
        this.nome = nome;
        this.usuario = usuario;
        this.senha = senha;
        this.cargo = cargo;
        this.ativo = ativo;
    }

    public int getIdFuncionario() {
        return idFuncionario;
    }

    public void setIdFuncionario(int idFuncionario) {
        this.idFuncionario = idFuncionario;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public String getCargo() {
        return cargo;
    }

    public void setCargo(String cargo) {
        this.cargo = cargo;
    }

    public boolean isAtivo() {
        return ativo;
    }

    public void setAtivo(boolean ativo) {
        this.ativo = ativo;
    }

    @Override
    public String toString() {
        return nome + " (" + cargo + ")";
    }
}

