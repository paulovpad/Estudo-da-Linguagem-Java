package sisoff.model;

public class AtivoOffshore {

    private int idAtivo;
    private String nomeAtivo;
    private String tipoAtivo;
    private String localizacao;
    private String operador;

    public AtivoOffshore() {
    }

    public AtivoOffshore(int idAtivo, String nomeAtivo, String tipoAtivo, String localizacao, String operador) {
        this.idAtivo = idAtivo;
        this.nomeAtivo = nomeAtivo;
        this.tipoAtivo = tipoAtivo;
        this.localizacao = localizacao;
        this.operador = operador;
    }

    // Construtor sem id
    public AtivoOffshore(String nomeAtivo, String tipoAtivo, String localizacao, String operador) {
        this.nomeAtivo = nomeAtivo;
        this.tipoAtivo = tipoAtivo;
        this.localizacao = localizacao;
        this.operador = operador;
    }

    public int getIdAtivo() {
        return idAtivo;
    }

    public void setIdAtivo(int idAtivo) {
        this.idAtivo = idAtivo;
    }

    public String getNomeAtivo() {
        return nomeAtivo;
    }

    public void setNomeAtivo(String nomeAtivo) {
        this.nomeAtivo = nomeAtivo;
    }

    public String getTipoAtivo() {
        return tipoAtivo;
    }

    public void setTipoAtivo(String tipoAtivo) {
        this.tipoAtivo = tipoAtivo;
    }

    public String getLocalizacao() {
        return localizacao;
    }

    public void setLocalizacao(String localizacao) {
        this.localizacao = localizacao;
    }

    public String getOperador() {
        return operador;
    }

    public void setOperador(String operador) {
        this.operador = operador;
    }

    @Override
    public String toString() {
        return nomeAtivo + " - " + tipoAtivo;
    }
}

