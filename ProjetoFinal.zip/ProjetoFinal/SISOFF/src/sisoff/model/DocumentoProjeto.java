package sisoff.model;

import java.sql.Date;

public class DocumentoProjeto {

    private int idDocumento;
    private int idProjeto;
    private Integer idEtapa; // pode ser nulo

    private String titulo;
    private String tipoDocumento;
    private Date dataEmissao;
    private String responsavelElaboracao;
    private String observacao;

    public int getIdDocumento() {
        return idDocumento;
    }

    public void setIdDocumento(int idDocumento) {
        this.idDocumento = idDocumento;
    }

    public int getIdProjeto() {
        return idProjeto;
    }

    public void setIdProjeto(int idProjeto) {
        this.idProjeto = idProjeto;
    }

    public Integer getIdEtapa() {
        return idEtapa;
    }

    public void setIdEtapa(Integer idEtapa) {
        this.idEtapa = idEtapa;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getTipoDocumento() {
        return tipoDocumento;
    }

    public void setTipoDocumento(String tipoDocumento) {
        this.tipoDocumento = tipoDocumento;
    }

    public Date getDataEmissao() {
        return dataEmissao;
    }

    public void setDataEmissao(Date dataEmissao) {
        this.dataEmissao = dataEmissao;
    }

    public String getResponsavelElaboracao() {
        return responsavelElaboracao;
    }

    public void setResponsavelElaboracao(String responsavelElaboracao) {
        this.responsavelElaboracao = responsavelElaboracao;
    }

    public String getObservacao() {
        return observacao;
    }

    public void setObservacao(String observacao) {
        this.observacao = observacao;
    }
}
