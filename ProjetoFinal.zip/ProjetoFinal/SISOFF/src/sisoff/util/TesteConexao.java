package sisoff.util;

import java.sql.Connection;

public class TesteConexao {
    public static void main(String[] args) {
        Connection conn = null;
        try {
            conn = ConnectionFactory.getConnection();
            System.out.println("Conexão realizada com sucesso!");
        } catch (Exception e) {
            System.err.println("Falha na conexão: " + e.getMessage());
        } finally {
            ConnectionFactory.closeConnection(conn);
        }
    }
}
