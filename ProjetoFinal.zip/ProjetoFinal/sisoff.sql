-- 1) Criar o banco
CREATE DATABASE IF NOT EXISTS sisoff
  DEFAULT CHARACTER SET utf8mb4
  DEFAULT COLLATE utf8mb4_unicode_ci;

-- 2) Usar o banco
USE sisoff;

-- 3) Criar tabela FUNCIONARIO
CREATE TABLE funcionario (
    id_funcionario INT AUTO_INCREMENT PRIMARY KEY,
    nome           VARCHAR(100) NOT NULL,
    usuario        VARCHAR(50)  NOT NULL UNIQUE,
    senha          VARCHAR(255) NOT NULL,
    cargo          VARCHAR(50),
    ativo          TINYINT(1)   NOT NULL DEFAULT 1
) ENGINE = InnoDB;

-- 4) Criar tabela ATIVO_OFFSHORE
CREATE TABLE ativo_offshore (
    id_ativo      INT AUTO_INCREMENT PRIMARY KEY,
    nome_ativo    VARCHAR(100) NOT NULL,
    tipo_ativo    VARCHAR(50)  NOT NULL,   -- Ex.: FPSO, Plataforma, Embarcação
    localizacao   VARCHAR(100),            -- Ex.: Bacia de Campos
    operador      VARCHAR(100)             -- Ex.: Petrobras, Equinor
) ENGINE = InnoDB;

-- 5) Criar tabela PROJETO_OFFSHORE
CREATE TABLE projeto_offshore (
    id_projeto        INT AUTO_INCREMENT PRIMARY KEY,
    id_ativo          INT         NOT NULL,
    id_responsavel    INT         NULL,
    nome_projeto      VARCHAR(150) NOT NULL,
    tipo_projeto      VARCHAR(50)  NOT NULL,  -- Manutenção, Inspeção, Intervenção, etc.
    data_inicio       DATE,
    data_fim_prevista DATE,
    status            VARCHAR(30)  NOT NULL,  -- Planejado, Em andamento, Concluído...
    descricao         TEXT,

    CONSTRAINT fk_projeto_ativo
        FOREIGN KEY (id_ativo)
        REFERENCES ativo_offshore (id_ativo)
        ON UPDATE CASCADE
        ON DELETE RESTRICT,

    CONSTRAINT fk_projeto_responsavel
        FOREIGN KEY (id_responsavel)
        REFERENCES funcionario (id_funcionario)
        ON UPDATE CASCADE
        ON DELETE SET NULL
) ENGINE = InnoDB;

-- 6) Criar tabela ETAPA_PROJETO
CREATE TABLE etapa_projeto (
    id_etapa             INT AUTO_INCREMENT PRIMARY KEY,
    id_projeto           INT          NOT NULL,
    nome_etapa           VARCHAR(100) NOT NULL, -- Planejamento, Mobilização, Execução...
    responsavel_etapa    VARCHAR(100),
    data_prevista_inicio DATE,
    data_prevista_fim    DATE,
    data_conclusao       DATE,
    status_etapa         VARCHAR(30)  NOT NULL, -- Pendente, Em andamento, Concluída...
    observacao           TEXT,

    CONSTRAINT fk_etapa_projeto
        FOREIGN KEY (id_projeto)
        REFERENCES projeto_offshore (id_projeto)
        ON UPDATE CASCADE
        ON DELETE CASCADE
) ENGINE = InnoDB;

-- 7) Criar tabela DOCUMENTO_PROJETO
CREATE TABLE documento_projeto (
    id_documento          INT AUTO_INCREMENT PRIMARY KEY,
    id_projeto            INT          NOT NULL,
    id_etapa              INT          NULL,
    titulo                VARCHAR(150) NOT NULL,
    tipo_documento        VARCHAR(50)  NOT NULL, -- Plano, Relatório, Cronograma, ATA...
    data_emissao          DATE,
    responsavel_elaboracao VARCHAR(100),
    observacao            TEXT,

    CONSTRAINT fk_doc_projeto
        FOREIGN KEY (id_projeto)
        REFERENCES projeto_offshore (id_projeto)
        ON UPDATE CASCADE
        ON DELETE CASCADE,

    CONSTRAINT fk_doc_etapa
        FOREIGN KEY (id_etapa)
        REFERENCES etapa_projeto (id_etapa)
        ON UPDATE CASCADE
        ON DELETE SET NULL
) ENGINE = InnoDB;

----------------------------------------------------
-- 8) POPULAR AS TABELAS COM DADOS OFFSHORE
----------------------------------------------------

-- FUNCIONÁRIOS
INSERT INTO funcionario (id_funcionario, nome, usuario, senha, cargo, ativo) VALUES
(1, 'Matheus Planejamento', 'mplanej', '123', 'Planejador Offshore', 1),
(2, 'Gabriel Souza',        'gsouza',  '123', 'Engenheiro Submarino', 1),
(3, 'Ana Beatriz',          'abeatriz','123', 'Engenheira de Projetos', 1),
(4, 'Carlos Eduardo',       'ceduardo','123', 'Supervisor Offshore', 1),
(5, 'João Silva',           'jsilva',  '123', 'Técnico de Campo', 1),
(6, 'Paulo Victor',           'pv',  '123', 'Gerente', 1);


-- ATIVOS OFFSHORE
INSERT INTO ativo_offshore (id_ativo, nome_ativo, tipo_ativo, localizacao, operador) VALUES
(1, 'FPSO Guanabara',       'FPSO',                'Bacia de Santos – Campo de Mero', 'Petrobras'),
(2, 'Plataforma P-68',      'Plataforma fixa',     'Bacia de Santos',                 'Petrobras'),
(3, 'SV-01 Support Vessel', 'Embarcação de apoio', 'Bacia de Campos',                 'Empresa Offshore X');

-- PROJETOS OFFSHORE
INSERT INTO projeto_offshore (
    id_projeto, id_ativo, id_responsavel,
    nome_projeto, tipo_projeto,
    data_inicio, data_fim_prevista,
    status, descricao
) VALUES
(1, 1, 1,
 'Campanha de Inspeção Submarina - Mero',
 'Inspeção',
 '2025-02-10', '2025-03-05',
 'Em andamento',
 'Campanha de inspeção com ROV nas linhas de produção e exportação do campo de Mero, FPSO Guanabara.'),

(2, 2, 3,
 'Manutenção Programada - P-68',
 'Manutenção',
 '2025-04-01', '2025-04-20',
 'Planejado',
 'Parada de manutenção programada na plataforma P-68, incluindo sistemas elétricos e de processo.'),

(3, 3, 2,
 'Intervenção em Umbilical - Bacia de Campos',
 'Intervenção Submarina',
 '2025-05-05', '2025-05-18',
 'Planejado',
 'Intervenção corretiva em um umbilical de controle localizado na Bacia de Campos.'),

(4, 1, 4,
 'Documentação Técnica - FPSO Guanabara',
 'Documentação Técnica',
 '2025-01-05', '2025-01-30',
 'Concluído',
 'Consolidação de documentação técnica e relatórios da campanha anterior no FPSO Guanabara.');

-- ETAPAS DE PROJETO
INSERT INTO etapa_projeto (
    id_etapa, id_projeto,
    nome_etapa, responsavel_etapa,
    data_prevista_inicio, data_prevista_fim,
    data_conclusao, status_etapa,
    observacao
) VALUES
-- Projeto 1: Campanha de Inspeção Submarina - Mero
(1, 1,
 'Planejamento da Campanha',
 'Matheus Planejamento',
 '2025-01-15', '2025-01-31',
 '2025-01-28', 'Concluída',
 'Definição de escopo, janelas meteorológicas, recursos de ROV e equipe.'),

(2, 1,
 'Execução das Inspeções ROV',
 'Gabriel Souza',
 '2025-02-10', '2025-02-25',
 NULL, 'Em andamento',
 'Inspeções em linhas de produção, exportação e risers. Aguardando janela de bom tempo.'),

-- Projeto 2: Manutenção Programada - P-68
(3, 2,
 'Planejamento da Parada de Manutenção',
 'Ana Beatriz',
 '2025-03-01', '2025-03-10',
 NULL, 'Pendente',
 'Levantamento de escopo detalhado da parada, priorização de atividades e integração com operação.'),

(4, 2,
 'Execução da Parada de Manutenção',
 'Carlos Eduardo',
 '2025-04-01', '2025-04-20',
 NULL, 'Pendente',
 'Execução da parada geral, incluindo inspeções, trocas de componentes e testes funcionais.'),

-- Projeto 3: Intervenção em Umbilical
(5, 3,
 'Análise de Risco da Intervenção',
 'Ana Beatriz',
 '2025-04-05', '2025-04-12',
 NULL, 'Pendente',
 'Análise de riscos operacionais e definição de medidas de mitigação para a intervenção em umbilical.'),

-- Projeto 4: Documentação Técnica – FPSO Guanabara
(6, 4,
 'Consolidação de Relatórios Técnicos',
 'Matheus Planejamento',
 '2025-01-05', '2025-01-20',
 '2025-01-19', 'Concluída',
 'Compilação dos relatórios de inspeção, registros fotográficos e ATAs de reunião.');

-- DOCUMENTOS DE PROJETO
INSERT INTO documento_projeto (
    id_documento,
    id_projeto, id_etapa,
    titulo, tipo_documento,
    data_emissao,
    responsavel_elaboracao,
    observacao
) VALUES
-- Projeto 1 - Campanha de Inspeção Submarina - Mero
(1,
 1, 1,
 'Plano de Trabalho - Campanha de Inspeção Mero',
 'Plano de Trabalho',
 '2025-01-10',
 'Matheus Planejamento',
 'Plano de trabalho aprovado pelo cliente, contendo escopo, cronograma macro e recursos necessários.'),

(2,
 1, 2,
 'Relatório Parcial de Inspeção - Mero',
 'Relatório de Inspeção',
 '2025-02-20',
 'Gabriel Souza',
 'Relatório parcial com as primeiras anomalias identificadas nas linhas de produção.'),

-- Projeto 2 - Manutenção Programada - P-68
(3,
 2, 3,
 'Cronograma da Parada de Manutenção - P-68',
 'Cronograma',
 '2025-03-05',
 'Ana Beatriz',
 'Cronograma detalhado das atividades da parada, incluindo janelas de parada e retorno.'),

(4,
 2, 4,
 'Check-list de Liberação da Plataforma - P-68',
 'Check-list',
 '2025-04-21',
 'Carlos Eduardo',
 'Check-list a ser utilizado para a liberação da plataforma após a parada completa.'),

-- Projeto 3 - Intervenção em Umbilical
(5,
 3, 5,
 'ATA de Reunião - Análise de Risco da Intervenção em Umbilical',
 'ATA de Reunião',
 '2025-04-10',
 'Ana Beatriz',
 'Registro das decisões da reunião de análise de risco, com participação de operação, manutenção e HSE.'),

-- Projeto 4 - Documentação Técnica - FPSO Guanabara
(6,
 4, 6,
 'Relatório Técnico Final - FPSO Guanabara',
 'Relatório Técnico',
 '2025-01-30',
 'Carlos Eduardo',
 'Relatório final consolidando resultados da campanha anterior, com recomendações e conclusão.'),

(7,
 4, 6,
 'Documentação Fotográfica - FPSO Guanabara',
 'Documentação Fotográfica',
 '2025-01-25',
 'João Silva',
 'Pacote de imagens referentes às inspeções visuais realizadas no casco e estruturas topside.');

