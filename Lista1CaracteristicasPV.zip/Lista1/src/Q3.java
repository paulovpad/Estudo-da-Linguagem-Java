import java.util.Scanner;

public class Q3 {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);

        System.out.print("Informe o consumo em m³: ");
        int consumo = entrada.nextInt();

        double valor = 7.0; // assinatura básica (até 10 m³)

        if (consumo > 10) {
            int acima10 = consumo - 10;

            // Faixa 11–30 → R$1,00 cada
            if (acima10 <= 20) {
                valor += acima10 * 1.0;
                acima10 = 0;
            } else {
                valor += 20 * 1.0;
                acima10 -= 20;
            }

            // Faixa 31–100 → R$2,00 cada
            if (acima10 > 0) {
                if (acima10 <= 70) {
                    valor += acima10 * 2.0;
                    acima10 = 0;
                } else {
                    valor += 70 * 2.0;
                    acima10 -= 70;
                }
            }

            // Acima de 100 → R$5,00 cada
            if (acima10 > 0) {
                valor += acima10 * 5.0;
            }
        }

        System.out.printf("Valor da conta: R$%.2f%n", valor);
    }
}
