import java.util.Scanner;

public class Q5 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Digite a quantidade de linhas (horizontal): ");
        int linhas = input.nextInt();   // ex.: 8

        System.out.print("Digite a quantidade de colunas (vertical): ");
        int colunas = input.nextInt();  // ex.: 7

        int linhaAtual = 0;
        while (linhaAtual < linhas) {   // usei while em vez de for
            // deslocamento nas linhas ímpares
            if (linhaAtual % 2 != 0) {
                System.out.print(" ");
            }

            for (int j = 0; j < colunas; j++) {
                System.out.print("*");
                if (j < colunas - 1) {
                    System.out.print(" ");
                }
            }
            System.out.println();
            linhaAtual++;
        }
    }
}
