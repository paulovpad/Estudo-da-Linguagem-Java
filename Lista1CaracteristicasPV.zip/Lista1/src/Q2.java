import java.util.Scanner;

public class Q2 {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);

        // Leitura dos três lados
        System.out.print("Digite o valor do lado A: ");
        int a = entrada.nextInt();
        System.out.print("Digite o valor do lado B: ");
        int b = entrada.nextInt();
        System.out.print("Digite o valor do lado C: ");
        int c = entrada.nextInt();

        // Descobrir qual é o maior lado
        int maior = a;
        int lado1 = b;
        int lado2 = c;

        if (b > maior && b >= c) {
            maior = b;
            lado1 = a;
            lado2 = c;
        } else if (c > maior && c >= b) {
            maior = c;
            lado1 = a;
            lado2 = b;
        }

        // Verificar condições do enunciado
        if (maior >= lado1 + lado2) {
            System.out.println("Nenhum triângulo é formado.");
        } else {
            int maior2 = maior * maior;
            int soma = lado1 * lado1 + lado2 * lado2;

            if (maior2 == soma) {
                System.out.println("Triângulo retângulo");
            } else if (maior2 > soma) {
                System.out.println("Triângulo obtusângulo");
            } else {
                System.out.println("Triângulo acutângulo");
            }
        }
    }
}
