import java.util.Scanner;

public class Q8 {
    // Converte taxa anual para mensal
    static double converterTaxa(double taxa, boolean anual) {
        if (anual) {
            return Math.pow(1 + taxa, 1.0 / 12.0) - 1;
        }
        return taxa;
    }

    // Simula evolução mês a mês
    static double evoluirSaldo(double inicial, double taxaMensal, double aporte, int meses) {
        double saldo = inicial;
        int mes = 0;
        while (mes < meses) {
            saldo = saldo * (1 + taxaMensal) + aporte;
            mes++;
        }
        return saldo;
    }

    // Calcula em quantos meses atinge a meta
    static int calcularPrazo(double inicial, double taxaMensal, double aporte, double objetivo) {
        double saldo = inicial;
        int meses = 0;
        while (saldo < objetivo && meses < 1200) { // trava: 100 anos
            saldo = saldo * (1 + taxaMensal) + aporte;
            meses++;
        }
        return (saldo >= objetivo) ? meses : -1;
    }

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);

        System.out.print("Capital inicial: ");
        double capital = teclado.nextDouble();

        System.out.print("Taxa de juros (ex.: 0.05): ");
        double taxa = teclado.nextDouble();

        System.out.print("Digite 1 se a taxa é anual, 0 se for mensal: ");
        boolean anual = teclado.nextInt() == 1;

        System.out.print("Aporte mensal: ");
        double aporte = teclado.nextDouble();

        System.out.print("Período (anos): ");
        int anos = teclado.nextInt();

        System.out.print("Meses adicionais: ");
        int meses = teclado.nextInt();

        System.out.print("Valor objetivo: ");
        double objetivo = teclado.nextDouble();

        int totalMeses = anos * 12 + meses;
        double txInvest = converterTaxa(taxa, anual);
        double txPoup = 0.005; // 0,5% ao mês

        double saldoInvest = evoluirSaldo(capital, txInvest, aporte, totalMeses);
        double saldoPoup = evoluirSaldo(capital, txPoup, aporte, totalMeses);

        int prazoInvest = calcularPrazo(capital, txInvest, aporte, objetivo);
        int prazoPoup = calcularPrazo(capital, txPoup, aporte, objetivo);

        System.out.printf("Investimento após %d meses: R$%.2f%n", totalMeses, saldoInvest);
        System.out.printf("Poupança após %d meses: R$%.2f%n", totalMeses, saldoPoup);

        if (prazoInvest != -1) {
            System.out.printf("Meta atingida em %d anos e %d meses (investimento)%n",
                              prazoInvest / 12, prazoInvest % 12);
        } else {
            System.out.println("Meta não atingida no investimento em 100 anos.");
        }

        if (prazoPoup != -1) {
            System.out.printf("Meta atingida em %d anos e %d meses (poupança)%n",
                              prazoPoup / 12, prazoPoup % 12);
        } else {
            System.out.println("Meta não atingida na poupança em 100 anos.");
        }
    }
}
