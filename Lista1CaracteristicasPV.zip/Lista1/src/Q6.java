import java.util.Scanner;

public class Q6 {
    // Método para verificar se é perfeito
    static boolean numeroPerfeito(int valor) {
        if (valor < 2) return false;

        int somaDivisores = 1; // 1 sempre é divisor
        int divisor = 2;

        // percorre até a metade do número
        while (divisor <= valor / 2) {
            if (valor % divisor == 0) {
                somaDivisores += divisor;
            }
            divisor++;
        }
        return somaDivisores == valor;
    }

    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);

        System.out.print("Digite um número inteiro positivo: ");
        int n = entrada.nextInt();

        if (numeroPerfeito(n)) {
            System.out.println(n + " é um número perfeito!");
        } else {
            System.out.println(n + " não é um número perfeito.");
        }
    }
}
