import java.util.Scanner;

public class Q7 {
    // Função para calcular e mostrar os saldos
    static void mostrarJuros(double principal, double taxa, int anos) {
        int anoAtual = 1;
        double acumulado = principal;

        while (anoAtual <= anos) {
            acumulado = principal * Math.pow(1 + taxa, anoAtual);
            System.out.printf("%d %.2f%n", anoAtual, acumulado);
            anoAtual++;
        }
    }

    public static void main(String[] args) {
        Scanner leitor = new Scanner(System.in);

        System.out.print("Digite o valor inicial: ");
        double p = leitor.nextDouble();

        System.out.print("Digite a taxa anual (ex.: 0.05 para 5%): ");
        double r = leitor.nextDouble();

        System.out.print("Digite o número de anos: ");
        int n = leitor.nextInt();

        mostrarJuros(p, r, n);
    }
}
