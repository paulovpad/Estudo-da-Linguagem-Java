import java.util.Scanner;

public class Q1 {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);

        // Entrada
        System.out.print("Informe o dia: ");
        int dia = teclado.nextInt();
        System.out.print("Informe o mês: ");
        int mes = teclado.nextInt();
        System.out.print("Informe o ano: ");
        int ano = teclado.nextInt();

        // 1) Concatenar DDMM e somar com o ano
        int numero = (dia * 100 + mes) + ano;

        // 2) Extrair os dois primeiros e os dois últimos dígitos
        String str = String.format("%04d", numero); // garante pelo menos 4 dígitos
        int parte1 = Integer.parseInt(str.substring(0, 2));
        int parte2 = Integer.parseInt(str.substring(str.length() - 2));
        int soma = parte1 + parte2;

        // 3) Redução até ficar de 1 dígito
        int digito = soma;
        while (digito >= 10) {
            int somaDigitos = 0;
            for (char c : String.valueOf(digito).toCharArray()) {
                somaDigitos += c - '0';
            }
            digito = somaDigitos;
        }

        // 4) Ajuste: se for 9, vira 3
        if (digito == 9) digito = 3;

        // 5) Perfil pelo resto da divisão por 5
        String[] perfis = {"Tímido", "Sonhador", "Paquerador", "Atraente", "Irresistível"};
        int indice = digito % 5;

        // Saída
        System.out.println("Perfil: " + perfis[indice]);
    }
}
