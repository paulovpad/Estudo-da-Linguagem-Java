import java.util.Scanner;

public class Q4 {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);

        System.out.print("Digite o valor de n: ");
        int n = entrada.nextInt();

        int linha = 1;                 // quantos * a linha atual terá
        while (linha <= n) {           // controla as linhas
            StringBuilder sb = new StringBuilder();

            int k = linha;             // contador decrescente de asteriscos
            while (k > 0) {
                sb.append('*');
                k--;                   // diferente da versão anterior (agora decresce)
            }

            System.out.println(sb.toString());
            linha++;
        }
    }
}
