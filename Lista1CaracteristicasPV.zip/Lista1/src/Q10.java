import java.util.Scanner;

public class Q10 {
    static Scanner in = new Scanner(System.in);

    // Cria matriz com instruções claras
    static int[][] novaMatriz(int linhas, int colunas, String nome) {
        int[][] M = new int[linhas][colunas];
        System.out.println("→ Criando matriz " + nome + " de " + linhas + "x" + colunas);
        System.out.println("→ Digite " + (linhas * colunas) + " valores (linha a linha):");
        for (int i = 0; i < linhas; i++) {
            for (int j = 0; j < colunas; j++) {
                M[i][j] = in.nextInt();
            }
        }
        System.out.println("✓ Matriz " + nome + " criada.");
        return M;
    }

    // Impressão alinhada
    static void exibir(String titulo, int[][] M) {
        if (M == null) {
            System.out.println(titulo + ": (matriz não criada)");
            return;
        }
        System.out.println(titulo + " (" + M.length + "x" + M[0].length + "):");
        int width = 1;
        for (int[] linha : M)
            for (int v : linha)
                width = Math.max(width, Integer.toString(v).length());
        String fmt = "%" + (width + 1) + "d";

        for (int[] linha : M) {
            StringBuilder sb = new StringBuilder();
            for (int v : linha) sb.append(String.format(fmt, v));
            System.out.println(sb.toString());
        }
    }

    static int[][] somar(int[][] A, int[][] B) {
        if (A == null || B == null) return null;
        if (A.length != B.length || A[0].length != B[0].length) return null;
        int n = A.length, m = A[0].length;
        int[][] R = new int[n][m];
        for (int i = 0; i < n; i++)
            for (int j = 0; j < m; j++)
                R[i][j] = A[i][j] + B[i][j];
        return R;
    }

    static int[][] vezesEscalar(int[][] A, int k) {
        if (A == null) return null;
        int n = A.length, m = A[0].length;
        int[][] R = new int[n][m];
        for (int i = 0; i < n; i++)
            for (int j = 0; j < m; j++)
                R[i][j] = A[i][j] * k;
        return R;
    }

    static int[][] multiplicar(int[][] A, int[][] B) {
        if (A == null || B == null) return null;
        if (A[0].length != B.length) return null; // cols(A) == rows(B)
        int n = A.length, p = A[0].length, m = B[0].length;
        int[][] R = new int[n][m];
        for (int i = 0; i < n; i++)
            for (int j = 0; j < m; j++) {
                int s = 0;
                for (int k = 0; k < p; k++) s += A[i][k] * B[k][j];
                R[i][j] = s;
            }
        return R;
    }

    public static void main(String[] args) {
        int[][] A = null, B = null;

        while (true) {
            System.out.println("\n===== MENU MATRIZES =====");
            System.out.println("1) Criar matriz A");
            System.out.println("2) Criar matriz B");
            System.out.println("3) Somar A + B");
            System.out.println("4) Multiplicar A por escalar k");
            System.out.println("5) Multiplicar A x B");
            System.out.println("6) Mostrar A");
            System.out.println("7) Mostrar B");
            System.out.println("0) Sair");
            System.out.print("Opção: ");

            int op = in.hasNextInt() ? in.nextInt() : -1;
            if (op == 0) { System.out.println("Encerrando..."); break; }

            switch (op) {
                case 1 -> {
                    System.out.print("Informe linhas e colunas de A (ex.: 2 3): ");
                    int n = in.nextInt(), m = in.nextInt();
                    A = novaMatriz(n, m, "A");
                    exibir("A", A);
                }
                case 2 -> {
                    System.out.print("Informe linhas e colunas de B (ex.: 3 2): ");
                    int n = in.nextInt(), m = in.nextInt();
                    B = novaMatriz(n, m, "B");
                    exibir("B", B);
                }
                case 3 -> {
                    int[][] S = somar(A, B);
                    if (S == null) {
                        System.out.println("× Não foi possível somar. Regras: A e B precisam existir e ter MESMAS dimensões.");
                        exibir("A", A); exibir("B", B);
                    } else exibir("A + B", S);
                }
                case 4 -> {
                    if (A == null) { System.out.println("× Crie A primeiro."); break; }
                    System.out.print("Informe k (inteiro): ");
                    int k = in.nextInt();
                    exibir("k * A", vezesEscalar(A, k));
                }
                case 5 -> {
                    int[][] P = multiplicar(A, B);
                    if (P == null) {
                        System.out.println("× Não foi possível multiplicar. Regra: cols(A) == rows(B) e ambas devem existir.");
                        exibir("A", A); exibir("B", B);
                    } else exibir("A x B", P);
                }
                case 6 -> exibir("A", A);
                case 7 -> exibir("B", B);
                default -> System.out.println("Opção inválida.");
            }
        }
    }
}
