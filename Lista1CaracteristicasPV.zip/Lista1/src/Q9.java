import java.util.Scanner;

public class Q9 {
    // Retorna o índice i do primeiro par consecutivo (arr[i], arr[i+1]) cuja soma é x.
    // Se não existir, retorna -1.
    static int buscaParConsecutivo(int[] arr, int x) {
        int i = 0;
        while (i + 1 < arr.length) {
            if (arr[i] + arr[i + 1] == x) {
                return i; // achou o primeiro par
            }
            i++;
        }
        return -1; // não encontrou
    }

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        System.out.print("Digite o tamanho do array: ");
        int n = in.nextInt();

        int[] v = new int[n];
        System.out.println("Digite os " + n + " elementos do array:");
        for (int k = 0; k < n; k++) {
            v[k] = in.nextInt();
        }

        System.out.print("Digite o valor x: ");
        int x = in.nextInt();

        int pos = buscaParConsecutivo(v, x);
        if (pos != -1) {
            // mesmo formato de saída: mostra valores e índices
            System.out.printf("Par encontrado: %d (índice %d) + %d (índice %d)%n",
                               v[pos], pos, v[pos + 1], pos + 1);
        } else {
            System.out.println("Nenhum par consecutivo encontrado.");
        }
    }
}
